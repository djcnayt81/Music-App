package com.example.audio.engine

import android.content.Context
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.pow

data class DeckPlayerState(
    val isLoaded: Boolean = false,
    val isPlaying: Boolean = false,
    val currentPositionMs: Int = 0,
    val durationMs: Int = 0,
    val speedMultiplier: Float = 1.0f,
    val pitchSemitones: Int = 0,
    val volume: Float = 1.0f
)

class DualDeckPlayer(private val context: Context, private val scope: CoroutineScope) {

    private var playerA: MediaPlayer? = null
    private var playerB: MediaPlayer? = null

    private val _stateDeckA = MutableStateFlow(DeckPlayerState())
    val stateDeckA = _stateDeckA.asStateFlow()

    private val _stateDeckB = MutableStateFlow(DeckPlayerState())
    val stateDeckB = _stateDeckB.asStateFlow()

    private var progressJob: Job? = null

    init {
        startProgressTracking()
    }

    fun loadTrackA(uri: Uri) {
        try {
            playerA?.release()
            playerA = MediaPlayer().apply {
                setDataSource(context, uri)
                isLooping = true
                prepare()
            }
            _stateDeckA.value = DeckPlayerState(
                isLoaded = true,
                isPlaying = false,
                durationMs = playerA?.duration ?: 0
            )
        } catch (_: Exception) {
            _stateDeckA.value = DeckPlayerState(isLoaded = false)
        }
    }

    fun loadTrackB(uri: Uri) {
        try {
            playerB?.release()
            playerB = MediaPlayer().apply {
                setDataSource(context, uri)
                isLooping = true
                prepare()
            }
            _stateDeckB.value = DeckPlayerState(
                isLoaded = true,
                isPlaying = false,
                durationMs = playerB?.duration ?: 0
            )
        } catch (_: Exception) {
            _stateDeckB.value = DeckPlayerState(isLoaded = false)
        }
    }

    fun togglePlayDeckA() {
        playerA?.let { player ->
            if (player.isPlaying) {
                player.pause()
                _stateDeckA.value = _stateDeckA.value.copy(isPlaying = false)
            } else {
                player.start()
                _stateDeckA.value = _stateDeckA.value.copy(isPlaying = true)
            }
        }
    }

    fun togglePlayDeckB() {
        playerB?.let { player ->
            if (player.isPlaying) {
                player.pause()
                _stateDeckB.value = _stateDeckB.value.copy(isPlaying = false)
            } else {
                player.start()
                _stateDeckB.value = _stateDeckB.value.copy(isPlaying = true)
            }
        }
    }

    fun playBothSimultaneously() {
        val anyPlaying = (playerA?.isPlaying == true) || (playerB?.isPlaying == true)
        if (anyPlaying) {
            playerA?.pause()
            playerB?.pause()
            _stateDeckA.value = _stateDeckA.value.copy(isPlaying = false)
            _stateDeckB.value = _stateDeckB.value.copy(isPlaying = false)
        } else {
            // Seek both to 0 and play in sync
            playerA?.seekTo(0)
            playerB?.seekTo(0)
            playerA?.start()
            playerB?.start()
            _stateDeckA.value = _stateDeckA.value.copy(isPlaying = true)
            _stateDeckB.value = _stateDeckB.value.copy(isPlaying = true)
        }
    }

    fun setSpeedDeckA(speed: Float) {
        _stateDeckA.value = _stateDeckA.value.copy(speedMultiplier = speed)
        applyPlaybackParamsA()
    }

    fun setPitchSemitonesDeckA(semitones: Int) {
        _stateDeckA.value = _stateDeckA.value.copy(pitchSemitones = semitones)
        applyPlaybackParamsA()
    }

    fun setSpeedDeckB(speed: Float) {
        _stateDeckB.value = _stateDeckB.value.copy(speedMultiplier = speed)
        applyPlaybackParamsB()
    }

    fun setPitchSemitonesDeckB(semitones: Int) {
        _stateDeckB.value = _stateDeckB.value.copy(pitchSemitones = semitones)
        applyPlaybackParamsB()
    }

    fun setVolumeDeckA(vol: Float) {
        val clamped = vol.coerceIn(0f, 1f)
        _stateDeckA.value = _stateDeckA.value.copy(volume = clamped)
        playerA?.setVolume(clamped, clamped)
    }

    fun setVolumeDeckB(vol: Float) {
        val clamped = vol.coerceIn(0f, 1f)
        _stateDeckB.value = _stateDeckB.value.copy(volume = clamped)
        playerB?.setVolume(clamped, clamped)
    }

    fun seekDeckA(positionMs: Int) {
        playerA?.seekTo(positionMs)
        _stateDeckA.value = _stateDeckA.value.copy(currentPositionMs = positionMs)
    }

    fun seekDeckB(positionMs: Int) {
        playerB?.seekTo(positionMs)
        _stateDeckB.value = _stateDeckB.value.copy(currentPositionMs = positionMs)
    }

    private fun applyPlaybackParamsA() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && playerA != null) {
            try {
                val state = _stateDeckA.value
                val pitchMultiplier = 2.0.pow(state.pitchSemitones.toDouble() / 12.0).toFloat()
                val params = PlaybackParams().apply {
                    speed = state.speedMultiplier.coerceIn(0.5f, 2.0f)
                    pitch = pitchMultiplier.coerceIn(0.5f, 2.0f)
                }
                playerA?.playbackParams = params
            } catch (_: Exception) {}
        }
    }

    private fun applyPlaybackParamsB() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && playerB != null) {
            try {
                val state = _stateDeckB.value
                val pitchMultiplier = 2.0.pow(state.pitchSemitones.toDouble() / 12.0).toFloat()
                val params = PlaybackParams().apply {
                    speed = state.speedMultiplier.coerceIn(0.5f, 2.0f)
                    pitch = pitchMultiplier.coerceIn(0.5f, 2.0f)
                }
                playerB?.playbackParams = params
            } catch (_: Exception) {}
        }
    }

    private fun startProgressTracking() {
        progressJob = scope.launch(Dispatchers.Main) {
            while (isActive) {
                playerA?.let { p ->
                    if (p.isPlaying) {
                        _stateDeckA.value = _stateDeckA.value.copy(
                            currentPositionMs = p.currentPosition,
                            isPlaying = true
                        )
                    }
                }
                playerB?.let { p ->
                    if (p.isPlaying) {
                        _stateDeckB.value = _stateDeckB.value.copy(
                            currentPositionMs = p.currentPosition,
                            isPlaying = true
                        )
                    }
                }
                delay(100)
            }
        }
    }

    fun release() {
        progressJob?.cancel()
        try {
            playerA?.stop()
            playerA?.release()
            playerA = null
        } catch (_: Exception) {}
        try {
            playerB?.stop()
            playerB?.release()
            playerB = null
        } catch (_: Exception) {}
    }
}
