package com.example.audio.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max

data class DecodedAudioData(
    val pcmMono: FloatArray,
    val sampleRate: Int,
    val channelCount: Int,
    val totalDurationMs: Long,
    val waveformPoints: FloatArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as DecodedAudioData
        return pcmMono.contentEquals(other.pcmMono) &&
                sampleRate == other.sampleRate &&
                channelCount == other.channelCount &&
                totalDurationMs == other.totalDurationMs &&
                waveformPoints.contentEquals(other.waveformPoints)
    }

    override fun hashCode(): Int {
        var result = pcmMono.contentHashCode()
        result = 31 * result + sampleRate
        result = 31 * result + channelCount
        result = 31 * result + totalDurationMs.hashCode()
        result = 31 * result + waveformPoints.contentHashCode()
        return result
    }
}

object LocalAudioDecoder {

    private const val TARGET_SAMPLE_RATE = 22050
    private const val MAX_ANALYSIS_SECONDS = 35 // Optimal window for ultra-fast and precise DSP
    private const val TIMEOUT_US = 5000L

    /**
     * Decodes audio from an Android Uri completely on-device using Phone CPU/RAM.
     */
    suspend fun decodeAudioLocally(
        context: Context,
        uri: Uri,
        onProgress: (Int) -> Unit = {}
    ): DecodedAudioData = withContext(Dispatchers.Default) {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null

        try {
            extractor.setDataSource(context, uri, null)
            val trackIndex = selectAudioTrack(extractor)
            if (trackIndex < 0) {
                throw IllegalArgumentException("No audio track found in selected file.")
            }

            extractor.selectTrack(trackIndex)
            val format = extractor.getTrackFormat(trackIndex)
            val mime = format.getString(MediaFormat.KEY_MIME)
                ?: throw IllegalArgumentException("Unknown audio mime type.")

            val originalSampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            } else {
                44100
            }

            val channelCount = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            } else {
                2
            }

            val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) {
                format.getLong(MediaFormat.KEY_DURATION)
            } else {
                0L
            }
            val durationMs = durationUs / 1000

            // If the song is longer than 60s, seek past the quiet intro to 15s to get the main rhythm
            if (durationMs > 60_000) {
                val seekTimeUs = 15_000_000L // 15 seconds in
                extractor.seekTo(seekTimeUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            }

            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            val maxSamplesToCollect = TARGET_SAMPLE_RATE * MAX_ANALYSIS_SECONDS
            val rawFloatList = ArrayList<Float>(maxSamplesToCollect)

            val bufferInfo = MediaCodec.BufferInfo()
            var isEos = false
            var samplesCollected = 0
            val downsampleStep = max(1, originalSampleRate / TARGET_SAMPLE_RATE)

            val maxRawSamplesToProcess = maxSamplesToCollect * downsampleStep * channelCount
            var totalInputBytesRead = 0

            while (!isEos && rawFloatList.size < maxSamplesToCollect) {
                // Feed input buffers
                val inIndex = codec.dequeueInputBuffer(TIMEOUT_US)
                if (inIndex >= 0) {
                    val inputBuffer = codec.getInputBuffer(inIndex)
                    if (inputBuffer != null) {
                        inputBuffer.clear()
                        val sampleSize = extractor.readSampleData(inputBuffer, 0)
                        if (sampleSize < 0) {
                            codec.queueInputBuffer(
                                inIndex, 0, 0, 0,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                        } else {
                            val sampleTime = extractor.getSampleTime()
                            codec.queueInputBuffer(inIndex, 0, sampleSize, sampleTime, 0)
                            extractor.advance()
                            totalInputBytesRead += sampleSize
                        }
                    }
                }

                // Retrieve output buffers
                val outIndex = codec.dequeueOutputBuffer(bufferInfo, TIMEOUT_US)
                if (outIndex >= 0) {
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        isEos = true
                    }

                    val outputBuffer = codec.getOutputBuffer(outIndex)
                    if (outputBuffer != null && bufferInfo.size > 0) {
                        outputBuffer.position(bufferInfo.offset)
                        outputBuffer.limit(bufferInfo.offset + bufferInfo.size)
                        outputBuffer.order(ByteOrder.LITTLE_ENDIAN)

                        val shortBuffer = outputBuffer.asShortBuffer()
                        val numShorts = shortBuffer.remaining()

                        var i = 0
                        while (i < numShorts && rawFloatList.size < maxSamplesToCollect) {
                            // Average channels to Mono
                            var monoSum = 0f
                            for (ch in 0 until channelCount) {
                                if (i + ch < numShorts) {
                                    monoSum += shortBuffer.get(i + ch) / 32768.0f
                                }
                            }
                            val monoSample = monoSum / channelCount
                            rawFloatList.add(monoSample)

                            // Skip for downsampling
                            i += (channelCount * downsampleStep)
                        }

                        val progress = (rawFloatList.size * 100 / maxSamplesToCollect).coerceIn(0, 100)
                        onProgress(progress)
                    }
                    codec.releaseOutputBuffer(outIndex, false)
                }
            }

            val pcmMono = rawFloatList.toFloatArray()

            // Generate 120-point visual waveform envelope
            val waveformPoints = generateWaveformPreview(pcmMono, 120)

            DecodedAudioData(
                pcmMono = pcmMono,
                sampleRate = TARGET_SAMPLE_RATE,
                channelCount = channelCount,
                totalDurationMs = durationMs,
                waveformPoints = waveformPoints
            )
        } finally {
            try {
                codec?.stop()
                codec?.release()
            } catch (_: Exception) {}
            try {
                extractor.release()
            } catch (_: Exception) {}
        }
    }

    private fun selectAudioTrack(extractor: MediaExtractor): Int {
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                return i
            }
        }
        return -1
    }

    private fun generateWaveformPreview(pcm: FloatArray, pointsCount: Int): FloatArray {
        val result = FloatArray(pointsCount)
        if (pcm.isEmpty()) return result

        val chunkSize = max(1, pcm.size / pointsCount)
        var maxPeak = 0.01f

        for (p in 0 until pointsCount) {
            val start = p * chunkSize
            val end = minOf(pcm.size, start + chunkSize)
            var sum = 0f
            var count = 0
            for (i in start until end) {
                sum += abs(pcm[i])
                count++
            }
            val avg = if (count > 0) sum / count else 0f
            result[p] = avg
            if (avg > maxPeak) maxPeak = avg
        }

        // Normalize 0.05 to 1.0
        for (p in 0 until pointsCount) {
            result[p] = (result[p] / maxPeak).coerceIn(0.08f, 1.0f)
        }

        return result
    }
}
