package com.example.audio.dsp

import com.example.model.MusicalKey
import com.example.model.PitchClass
import com.example.model.ScaleMode
import kotlin.math.ln
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * On-Device Musical Key & Scale Detector using Chromagram (Pitch Class Profile)
 * and Krumhansl-Schmuckler Key Profile Correlation.
 */
object KeyDetector {

    data class KeyResult(
        val musicalKey: MusicalKey,
        val confidence: Float,
        val chromaVector: FloatArray // 12 elements (C to B)
    ) {
        override fun equals(other: Any?): Boolean {
            if (this === other) return true
            if (javaClass != other?.javaClass) return false
            other as KeyResult
            return musicalKey == other.musicalKey &&
                    confidence == other.confidence &&
                    chromaVector.contentEquals(other.chromaVector)
        }

        override fun hashCode(): Int {
            var result = musicalKey.hashCode()
            result = 31 * result + confidence.hashCode()
            result = 31 * result + chromaVector.contentHashCode()
            return result
        }
    }

    // Krumhansl-Schmuckler key profiles for Major and Minor scales
    private val KRUMHANSL_MAJOR = floatArrayOf(
        6.35f, 2.23f, 3.48f, 2.33f, 4.38f, 4.09f, 2.52f, 5.19f, 2.39f, 3.66f, 2.29f, 2.88f
    )

    private val KRUMHANSL_MINOR = floatArrayOf(
        6.33f, 2.68f, 3.52f, 5.38f, 2.60f, 3.53f, 2.54f, 4.75f, 3.98f, 2.69f, 3.34f, 3.17f
    )

    // Reference pitch A4 = 440 Hz
    private const val A4_FREQ = 440.0
    private const val LN_2 = 0.69314718056

    /**
     * Analyzes PCM audio and determines the musical key and scale.
     */
    fun detectKey(pcm: FloatArray, sampleRate: Int): KeyResult {
        if (pcm.size < 4096) {
            return KeyResult(MusicalKey.C_MAJOR, 0.5f, FloatArray(12) { 1f / 12f })
        }

        val fftSize = 4096
        val hopSize = 2048
        val fft = FFT(fftSize)

        val real = FloatArray(fftSize)
        val imag = FloatArray(fftSize)
        val magnitudes = FloatArray(fftSize / 2 + 1)
        val chromaSum = FloatArray(12)

        val numFrames = (pcm.size - fftSize) / hopSize
        var validFrames = 0

        // Minimum and maximum frequency bounds for harmonic pitch detection (A1 ~ 55Hz to B6 ~ 1975Hz)
        val minFreq = 55f
        val maxFreq = 2000f

        val binFreqStep = sampleRate.toFloat() / fftSize

        for (f in 0 until numFrames step 2) { // Process every 2nd frame for 2x speed boost
            val offset = f * hopSize

            // Copy audio window
            for (i in 0 until fftSize) {
                real[i] = pcm[offset + i]
                imag[i] = 0f
            }

            fft.applyWindow(real)
            fft.transform(real, imag)
            fft.computeMagnitudes(real, imag, magnitudes)

            // Accumulate Pitch Class Profile
            var frameEnergy = 0f
            for (bin in 1 until magnitudes.size) {
                val freq = bin * binFreqStep
                if (freq in minFreq..maxFreq) {
                    val mag = magnitudes[bin]
                    if (mag > 0.001f) {
                        // MIDI pitch number = 69 + 12 * log2(freq / 440)
                        val midiPitch = 69.0 + (12.0 * (ln(freq.toDouble() / A4_FREQ) / LN_2))
                        val pitchClass = ((midiPitch.roundToInt() % 12) + 12) % 12

                        // Weight magnitude with logarithmic perception
                        val weightedMag = mag * mag
                        chromaSum[pitchClass] += weightedMag
                        frameEnergy += weightedMag
                    }
                }
            }

            if (frameEnergy > 0.01f) {
                validFrames++
            }
        }

        // Normalize Chromagram vector
        var totalChroma = 0f
        for (v in chromaSum) totalChroma += v
        if (totalChroma > 1e-6f) {
            for (i in 0 until 12) chromaSum[i] /= totalChroma
        } else {
            for (i in 0 until 12) chromaSum[i] = 1f / 12f
        }

        // Correlate with 24 keys (12 Major, 12 Minor)
        var bestCorrelation = -2f
        var bestPitchClass = PitchClass.C
        var bestMode = ScaleMode.MAJOR

        // Test Major Keys
        for (semitone in 0 until 12) {
            val rotatedProfile = rotateProfile(KRUMHANSL_MAJOR, semitone)
            val corr = pearsonCorrelation(chromaSum, rotatedProfile)
            if (corr > bestCorrelation) {
                bestCorrelation = corr
                bestPitchClass = PitchClass.fromSemitone(semitone)
                bestMode = ScaleMode.MAJOR
            }
        }

        // Test Minor Keys
        for (semitone in 0 until 12) {
            val rotatedProfile = rotateProfile(KRUMHANSL_MINOR, semitone)
            val corr = pearsonCorrelation(chromaSum, rotatedProfile)
            if (corr > bestCorrelation) {
                bestCorrelation = corr
                bestPitchClass = PitchClass.fromSemitone(semitone)
                bestMode = ScaleMode.MINOR
            }
        }

        val detectedKey = MusicalKey.find(bestPitchClass, bestMode)
        val normalizedConfidence = ((bestCorrelation + 1f) / 2f).coerceIn(0.6f, 0.96f)

        return KeyResult(detectedKey, normalizedConfidence, chromaSum)
    }

    private fun rotateProfile(profile: FloatArray, shift: Int): FloatArray {
        val result = FloatArray(12)
        for (i in 0 until 12) {
            val srcIdx = ((i - shift) % 12 + 12) % 12
            result[i] = profile[srcIdx]
        }
        return result
    }

    private fun pearsonCorrelation(x: FloatArray, y: FloatArray): Float {
        val n = 12
        var sumX = 0f
        var sumY = 0f
        for (i in 0 until n) {
            sumX += x[i]
            sumY += y[i]
        }
        val meanX = sumX / n
        val meanY = sumY / n

        var num = 0f
        var denX = 0f
        var denY = 0f

        for (i in 0 until n) {
            val diffX = x[i] - meanX
            val diffY = y[i] - meanY
            num += diffX * diffY
            denX += diffX * diffX
            denY += diffY * diffY
        }

        val den = sqrt(denX * denY)
        if (den < 1e-6f) return 0f
        return num / den
    }
}
