package com.example.audio.dsp

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Fast Fourier Transform (FFT) for audio spectral analysis.
 * Radix-2 In-place Cooley-Tukey implementation with Hann windowing.
 */
class FFT(val n: Int) {
    init {
        require(n > 0 && (n and (n - 1)) == 0) { "FFT size must be a power of 2, received $n" }
    }

    private val cosTable = FloatArray(n / 2)
    private val sinTable = FloatArray(n / 2)
    private val window = FloatArray(n)

    init {
        for (i in 0 until n / 2) {
            val angle = -2.0 * PI * i / n
            cosTable[i] = cos(angle).toFloat()
            sinTable[i] = sin(angle).toFloat()
        }
        // Pre-compute Hann Window
        for (i in 0 until n) {
            window[i] = (0.5 * (1.0 - cos(2.0 * PI * i / (n - 1)))).toFloat()
        }
    }

    /**
     * Applies Hann window to raw audio frame in place
     */
    fun applyWindow(frame: FloatArray, offset: Int = 0) {
        val len = minOf(n, frame.size - offset)
        for (i in 0 until len) {
            frame[offset + i] *= window[i]
        }
    }

    /**
     * Computes in-place FFT on real and imag arrays.
     * Both arrays must have length >= n.
     */
    fun transform(real: FloatArray, imag: FloatArray) {
        // Bit-reversal permutation
        var j = 0
        val n2 = n / 2
        for (i in 1 until n - 1) {
            var bit = n2
            while (j >= bit) {
                j -= bit
                bit = bit shr 1
            }
            j += bit
            if (i < j) {
                val tempR = real[i]
                real[i] = real[j]
                real[j] = tempR

                val tempI = imag[i]
                imag[i] = imag[j]
                imag[j] = tempI
            }
        }

        // Cooley-Tukey Radix-2 FFT
        var step = 2
        while (step <= n) {
            val halfStep = step / 2
            val tableStep = n / step

            for (k in 0 until n step step) {
                for (m in 0 until halfStep) {
                    val tableIndex = m * tableStep
                    val c = cosTable[tableIndex]
                    val s = sinTable[tableIndex]

                    val uR = real[k + m]
                    val uI = imag[k + m]

                    val vIndex = k + m + halfStep
                    val vR = real[vIndex]
                    val vI = imag[vIndex]

                    val tR = vR * c - vI * s
                    val tI = vR * s + vI * c

                    real[k + m] = uR + tR
                    imag[k + m] = uI + tI
                    real[vIndex] = uR - tR
                    imag[vIndex] = uI - tI
                }
            }
            step = step shl 1
        }
    }

    /**
     * Computes magnitude spectrum from real and imag arrays.
     * Output array size will be (n / 2) + 1.
     */
    fun computeMagnitudes(real: FloatArray, imag: FloatArray, magnitudes: FloatArray) {
        val half = (n / 2)
        for (i in 0..half) {
            magnitudes[i] = sqrt(real[i] * real[i] + imag[i] * imag[i])
        }
    }
}
