package com.example.audio.dsp

import com.example.model.GenreInfo
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

/**
 * On-device Audio Feature Extractor and Genre Classifier
 */
object GenreDetector {

    fun analyzeGenre(pcm: FloatArray, sampleRate: Int, bpm: Float): GenreInfo {
        if (pcm.size < 2048) {
            return GenreInfo(
                primaryGenre = "Electronic / Pop",
                subGenre = "Modern Mix",
                confidence = 0.85f,
                spectralBrightness = 0.65f,
                bassDensity = 0.7f,
                dynamicRangeDb = 12.0f
            )
        }

        // 1. Zero Crossing Rate (ZCR)
        var zeroCrossings = 0
        for (i in 1 until pcm.size) {
            if ((pcm[i] >= 0f && pcm[i - 1] < 0f) || (pcm[i] < 0f && pcm[i - 1] >= 0f)) {
                zeroCrossings++
            }
        }
        val zcr = zeroCrossings.toFloat() / pcm.size

        // 2. RMS Energy & Peak to RMS (Dynamic Range)
        var sumSquares = 0.0
        var peak = 0f
        for (s in pcm) {
            val absS = abs(s)
            if (absS > peak) peak = absS
            sumSquares += s * s
        }
        val rms = sqrt(sumSquares / pcm.size).toFloat()
        val crestFactor = if (rms > 1e-4f) peak / rms else 1f
        val dynamicRangeDb = (20f * log10(max(1f, crestFactor))).coerceIn(4f, 28f)

        // 3. Spectral Energy in Frequency Bands
        val fftSize = 2048
        val hopSize = 2048
        val fft = FFT(fftSize)
        val real = FloatArray(fftSize)
        val imag = FloatArray(fftSize)
        val magnitudes = FloatArray(fftSize / 2 + 1)

        val binHz = sampleRate.toFloat() / fftSize

        var subBassEnergy = 0f  // 20 - 120 Hz
        var lowMidEnergy = 0f   // 120 - 500 Hz
        var midEnergy = 0f      // 500 - 2500 Hz
        var highEnergy = 0f     // 2500 - 10000 Hz
        var totalMagSum = 0f
        var spectralCentroidSum = 0f

        val numFrames = (pcm.size - fftSize) / hopSize
        val framesToSample = minOf(numFrames, 30)
        val frameStep = maxOf(1, numFrames / maxOf(1, framesToSample))

        for (f in 0 until numFrames step frameStep) {
            val offset = f * hopSize
            for (i in 0 until fftSize) {
                real[i] = pcm[offset + i]
                imag[i] = 0f
            }
            fft.applyWindow(real)
            fft.transform(real, imag)
            fft.computeMagnitudes(real, imag, magnitudes)

            var frameWeightedFreq = 0f
            var frameTotalMag = 0f

            for (bin in 1 until magnitudes.size) {
                val freq = bin * binHz
                val mag = magnitudes[bin]

                frameWeightedFreq += freq * mag
                frameTotalMag += mag

                when {
                    freq in 20f..120f -> subBassEnergy += mag
                    freq in 120f..500f -> lowMidEnergy += mag
                    freq in 500f..2500f -> midEnergy += mag
                    freq in 2500f..10000f -> highEnergy += mag
                }
            }

            if (frameTotalMag > 1e-4f) {
                spectralCentroidSum += (frameWeightedFreq / frameTotalMag)
            }
            totalMagSum += frameTotalMag
        }

        val avgCentroid = if (framesToSample > 0) spectralCentroidSum / framesToSample else 1500f
        val brightness = (avgCentroid / 4000f).coerceIn(0.1f, 0.95f)

        val totalBands = subBassEnergy + lowMidEnergy + midEnergy + highEnergy
        val bassDensity = if (totalBands > 1e-4f) (subBassEnergy / totalBands * 3.5f).coerceIn(0.1f, 0.98f) else 0.5f

        // 4. Genre Classification Heuristics based on BPM + Spectrum
        val (primary, sub, conf) = when {
            // EDM / Dance (124 - 132 BPM, heavy sub-bass & high brightness)
            bpm in 122f..134f && bassDensity > 0.45f -> {
                Triple("EDM / Dance", "Mainstage / Club", 0.92f)
            }
            // House / Deep House (118 - 128 BPM, moderate dynamic range)
            bpm in 118f..128f && bassDensity > 0.35f -> {
                Triple("House / Groove", "Deep & Tech House", 0.89f)
            }
            // Hip-Hop / Trap (BPM 65-95 or 135-165, heavy sub bass, punchy transients)
            (bpm in 65f..98f || bpm in 135f..168f) && bassDensity > 0.48f -> {
                Triple("Hip-Hop / Trap", "808 Beat / Urban", 0.91f)
            }
            // Reggaeton / Latin / Moombah (90 - 110 BPM)
            bpm in 88f..112f && bassDensity > 0.40f -> {
                Triple("Reggaeton / Latin", "Dembow / Dancehall", 0.88f)
            }
            // Pop / Commercial (100 - 126 BPM, balanced spectrum)
            bpm in 98f..126f && brightness in 0.35f..0.75f -> {
                Triple("Pop / Commercial", "Vocal & Synth Pop", 0.87f)
            }
            // Rock / Alternative (high mids and high ZCR)
            zcr > 0.08f && brightness > 0.5f -> {
                Triple("Rock / Alternative", "Indie / Electric", 0.84f)
            }
            // R&B / Soul / Chill (slower tempos, warm brightness)
            bpm in 60f..100f && brightness < 0.5f -> {
                Triple("R&B / Soul", "Chill Neo-Soul", 0.86f)
            }
            // Default Modern Mix
            else -> {
                Triple("Modern Electronic / Pop", "Synth Beat", 0.82f)
            }
        }

        return GenreInfo(
            primaryGenre = primary,
            subGenre = sub,
            confidence = conf,
            spectralBrightness = brightness,
            bassDensity = bassDensity,
            dynamicRangeDb = dynamicRangeDb
        )
    }
}
