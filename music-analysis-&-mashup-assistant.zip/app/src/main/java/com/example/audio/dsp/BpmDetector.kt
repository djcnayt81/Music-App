package com.example.audio.dsp

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * High-performance on-device BPM (Tempo) Detection Engine
 * Uses Energy Flux Onset Detection + Comb Filter / Autocorrelation for accurate beat tracking.
 */
object BpmDetector {

    data class BpmResult(val bpm: Float, val confidence: Float)

    /**
     * Detects BPM from mono PCM float audio samples [-1.0f, 1.0f].
     * @param pcm Mono audio samples
     * @param sampleRate Sample rate in Hz (e.g. 22050 or 44100)
     */
    fun detectBpm(pcm: FloatArray, sampleRate: Int): BpmResult {
        if (pcm.size < sampleRate * 2) {
            return BpmResult(120.0f, 0.5f)
        }

        val frameSize = 1024
        val hopSize = 512
        val totalFrames = (pcm.size - frameSize) / hopSize

        if (totalFrames < 20) {
            return BpmResult(120.0f, 0.5f)
        }

        // 1. Calculate Onset Detection Function (ODF) using energy flux and sub-band transient energy
        val onsetCurve = FloatArray(totalFrames)
        var prevLowEnergy = 0f
        var prevMidEnergy = 0f
        var prevTotalEnergy = 0f

        val lowPassCoeff = 0.15f // Simple low-pass filter for kick drums

        var filteredSample = 0f

        for (f in 0 until totalFrames) {
            val start = f * hopSize
            var lowEnergy = 0f
            var midEnergy = 0f
            var totalEnergy = 0f

            for (i in 0 until frameSize) {
                val s = pcm[start + i]
                val sSq = s * s
                totalEnergy += sSq

                // Low-pass filter approximation for kick drum punch
                filteredSample += lowPassCoeff * (s - filteredSample)
                lowEnergy += filteredSample * filteredSample

                // High-pass transient component
                val highDiff = abs(s - filteredSample)
                midEnergy += highDiff * highDiff
            }

            // Rectified energy flux (only positive increases in energy)
            val fluxLow = max(0f, lowEnergy - prevLowEnergy)
            val fluxMid = max(0f, midEnergy - prevMidEnergy)
            val fluxTotal = max(0f, totalEnergy - prevTotalEnergy)

            // Weight low-end kick energy heavily for tempo tracking
            onsetCurve[f] = (fluxLow * 2.5f) + (fluxMid * 1.2f) + (fluxTotal * 0.5f)

            prevLowEnergy = lowEnergy
            prevMidEnergy = midEnergy
            prevTotalEnergy = totalEnergy
        }

        // Smooth and normalize onset curve
        normalizeInPlace(onsetCurve)

        // 2. Autocorrelation over BPM range (65 BPM to 185 BPM)
        val minBpm = 65f
        val maxBpm = 185f
        val fps = sampleRate.toFloat() / hopSize

        val minLag = (fps * 60f / maxBpm).toInt()
        val maxLag = (fps * 60f / minBpm).toInt().coerceAtMost(onsetCurve.size / 2)

        if (maxLag <= minLag) {
            return BpmResult(120f, 0.5f)
        }

        var bestScore = 0f
        var bestLag = minLag

        val scores = FloatArray(maxLag - minLag + 1)

        for (lag in minLag..maxLag) {
            var sum = 0f
            var count = 0
            for (i in 0 until (onsetCurve.size - lag)) {
                sum += onsetCurve[i] * onsetCurve[i + lag]
                count++
            }
            val corr = if (count > 0) sum / count else 0f
            scores[lag - minLag] = corr

            if (corr > bestScore) {
                bestScore = corr
                bestLag = lag
            }
        }

        // 3. Sub-harmonic & Octave peak refinement (Check for double-time vs half-time)
        val detectedBpm = (fps * 60f) / bestLag

        // Check if double BPM has significant energy (e.g. 64 -> 128)
        val doubleLag = bestLag / 2
        var finalBpm = detectedBpm

        if (doubleLag >= minLag) {
            val doubleScore = scores.getOrElse(doubleLag - minLag) { 0f }
            // If primary was slow (< 90) and double tempo has strong score
            if (detectedBpm < 90f && doubleScore > bestScore * 0.75f) {
                finalBpm = detectedBpm * 2f
            }
        }

        // Check if half BPM is preferable for very high tempos (> 165)
        val halfLag = bestLag * 2
        if (halfLag <= maxLag) {
            val halfScore = scores.getOrElse(halfLag - minLag) { 0f }
            if (detectedBpm > 165f && halfScore > bestScore * 0.85f) {
                finalBpm = detectedBpm / 2f
            }
        }

        // Parabolic interpolation around bestLag for sub-beat precision
        val refinedLag = refineLagParabolic(scores, bestLag - minLag) + minLag
        val precisionBpm = (fps * 60f) / refinedLag

        // Keep within normal musical range
        var candidateBpm = precisionBpm
        while (candidateBpm < 68f) candidateBpm *= 2f
        while (candidateBpm > 185f) candidateBpm /= 2f

        // Round to 1 decimal place
        val roundedBpm = (candidateBpm * 10f).toInt() / 10f
        val confidence = (bestScore * 2.5f).coerceIn(0.6f, 0.98f)

        return BpmResult(roundedBpm, confidence)
    }

    private fun normalizeInPlace(array: FloatArray) {
        var maxVal = 0f
        for (v in array) if (v > maxVal) maxVal = v
        if (maxVal > 1e-6f) {
            for (i in array.indices) array[i] /= maxVal
        }
    }

    private fun refineLagParabolic(scores: FloatArray, idx: Int): Float {
        if (idx <= 0 || idx >= scores.size - 1) return idx.toFloat()
        val y0 = scores[idx - 1]
        val y1 = scores[idx]
        val y2 = scores[idx + 1]
        val denom = 2f * (2f * y1 - y0 - y2)
        if (abs(denom) < 1e-6f) return idx.toFloat()
        val delta = (y0 - y2) / denom
        return idx + delta.coerceIn(-0.5f, 0.5f)
    }
}
