package com.example.audio.engine

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns

data class AudioMetadata(
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val bitrate: Long,
    val fileName: String
)

object AudioMetadataHelper {

    fun extractMetadata(context: Context, uri: Uri): AudioMetadata {
        val retriever = MediaMetadataRetriever()
        var fileName = getFileNameFromUri(context, uri)

        var title = ""
        var artist = ""
        var album = ""
        var durationMs = 0L
        var bitrate = 0L

        try {
            retriever.setDataSource(context, uri)
            title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: ""
            artist = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: ""
            album = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: ""
            val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationMs = durStr?.toLongOrNull() ?: 0L
            val bitStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
            bitrate = bitStr?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            // Fallback to filename
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }

        if (title.isBlank()) {
            title = fileName.substringBeforeLast(".")
            if (title.isBlank()) title = "Audio Track"
        }
        if (artist.isBlank()) {
            artist = "Local Artist"
        }

        return AudioMetadata(
            title = title,
            artist = artist,
            album = album,
            durationMs = durationMs,
            bitrate = bitrate,
            fileName = fileName
        )
    }

    private fun getFileNameFromUri(context: Context, uri: Uri): String {
        var result = uri.lastPathSegment ?: "audio_file.mp3"
        if (uri.scheme == "content") {
            try {
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1) {
                            val name = cursor.getString(nameIndex)
                            if (!name.isNullOrBlank()) {
                                result = name
                            }
                        }
                    }
                }
            } catch (_: Exception) {}
        }
        return result
    }
}
