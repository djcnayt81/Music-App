package com.example.audio.engine

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

data class DemoTrackPreset(
    val title: String,
    val artist: String,
    val targetBpm: Float,
    val targetKeyName: String,
    val baseFreqs: FloatArray, // Chord frequencies
    val genreHint: String,
    val fileName: String
)

object SampleAudioGenerator {

    val PRESET_DECK_A = DemoTrackPreset(
        title = "Neon Skyline (Club Anthem)",
        artist = "DJ Pulse Studio",
        targetBpm = 128.0f,
        targetKeyName = "C Major (8B)",
        baseFreqs = floatArrayOf(261.63f, 329.63f, 392.00f, 523.25f), // C4, E4, G4, C5 (C Major)
        genreHint = "EDM / Dance",
        fileName = "demo_track_c_major_128bpm.wav"
    )

    val PRESET_DECK_B = DemoTrackPreset(
        title = "Midnight Horizon (Melodic Groove)",
        artist = "Solaris Wave",
        targetBpm = 124.0f,
        targetKeyName = "A Minor (8A)",
        baseFreqs = floatArrayOf(220.00f, 261.63f, 329.63f, 440.00f), // A3, C4, E4, A4 (A Minor)
        genreHint = "House / Deep Groove",
        fileName = "demo_track_a_minor_124bpm.wav"
    )

    val PRESET_DECK_C = DemoTrackPreset(
        title = "Electric Sunset (Synthwave)",
        artist = "Hyperdrive",
        targetBpm = 126.0f,
        targetKeyName = "G Major (9B)",
        baseFreqs = floatArrayOf(196.00f, 246.94f, 293.66f, 392.00f), // G3, B3, D4, G4 (G Major)
        genreHint = "Pop / Commercial",
        fileName = "demo_track_g_major_126bpm.wav"
    )

    /**
     * Synthesizes a rhythmic WAV audio file locally on the device in cache.
     */
    suspend fun generateDemoWav(context: Context, preset: DemoTrackPreset): Uri = withContext(Dispatchers.IO) {
        val sampleRate = 22050
        val durationSeconds = 12 // 12 seconds sample loop
        val totalSamples = sampleRate * durationSeconds

        val file = File(context.cacheDir, preset.fileName)
        if (file.exists() && file.length() > 1000) {
            return@withContext Uri.fromFile(file)
        }

        val pcm = ShortArray(totalSamples)
        val beatInterval = (sampleRate * 60f / preset.targetBpm).toInt()

        val twoPi = 2.0 * PI

        for (i in 0 until totalSamples) {
            val timeSec = i.toDouble() / sampleRate
            val beatPhase = i % beatInterval
            val beatProgress = beatPhase.toFloat() / beatInterval

            // 1. Kick Drum (Punchy pitch envelope drop + sub bass)
            val kickEnv = exp(-beatProgress.toDouble() * 14.0)
            val kickFreq = 140.0 * exp(-beatProgress.toDouble() * 22.0) + 48.0
            val kick = sin(twoPi * kickFreq * (beatPhase.toDouble() / sampleRate)) * kickEnv

            // 2. Off-beat Hi-Hat / Shaker
            val hatPhase = (i + beatInterval / 2) % beatInterval
            val hatProgress = hatPhase.toFloat() / beatInterval
            val hatEnv = exp(-hatProgress.toDouble() * 24.0)
            val hatNoise = ((i * 1103515245 + 12345) % 32768 / 32768.0 - 0.5) * hatEnv * 0.35

            // 3. Harmonic Chord Synthesizer (C Major, A Minor, etc.)
            var chordSynth = 0.0
            for (freq in preset.baseFreqs) {
                // Pluck envelope on every 2 beats
                val barPhase = i % (beatInterval * 2)
                val barProgress = barPhase.toFloat() / (beatInterval * 2)
                val chordEnv = exp(-barProgress.toDouble() * 3.5)
                chordSynth += sin(twoPi * freq * timeSec) * chordEnv * 0.25
            }

            // 4. Sub Bassline
            val bassFreq = preset.baseFreqs[0] / 2.0
            val bass = sin(twoPi * bassFreq * timeSec) * 0.35

            val mixed = (kick * 0.55 + hatNoise * 0.2 + chordSynth * 0.35 + bass * 0.3)
            val clamped = mixed.coerceIn(-0.95, 0.95)
            pcm[i] = (clamped * 32767.0).toInt().toShort()
        }

        writeWavFile(file, pcm, sampleRate)
        Uri.fromFile(file)
    }

    private fun writeWavFile(file: File, pcm: ShortArray, sampleRate: Int) {
        val totalAudioLen = pcm.size * 2L
        val totalDataLen = totalAudioLen + 36
        val channels = 1
        val byteRate = sampleRate * channels * 2

        FileOutputStream(file).use { out ->
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)

            header.put("RIFF".toByteArray())
            header.putInt(totalDataLen.toInt())
            header.put("WAVE".toByteArray())
            header.put("fmt ".toByteArray())
            header.putInt(16) // Subchunk1Size for PCM
            header.putShort(1.toShort()) // AudioFormat 1 = PCM
            header.putShort(channels.toShort())
            header.putInt(sampleRate)
            header.putInt(byteRate)
            header.putShort((channels * 2).toShort()) // BlockAlign
            header.putShort(16.toShort()) // BitsPerSample
            header.put("data".toByteArray())
            header.putInt(totalAudioLen.toInt())

            out.write(header.array())

            val audioBuffer = ByteBuffer.allocate(pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            for (s in pcm) {
                audioBuffer.putShort(s)
            }
            out.write(audioBuffer.array())
        }
    }
}
