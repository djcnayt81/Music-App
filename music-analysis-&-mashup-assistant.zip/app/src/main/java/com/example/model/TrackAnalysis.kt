package com.example.model

import android.net.Uri

/**
 * Progress states during on-device audio decoding & DSP processing
 */
sealed class AnalysisProgress {
    object Idle : AnalysisProgress()
    data class ReadingMetadata(val step: String = "Reading file metadata...") : AnalysisProgress()
    data class DecodingPcm(val progressPercent: Int, val message: String = "Decoding audio locally (Phone CPU)...") : AnalysisProgress()
    data class DetectingBpm(val message: String = "Analyzing rhythmic onsets & BPM...") : AnalysisProgress()
    data class DetectingKey(val message: String = "Computing Chromagram & Harmonic Key...") : AnalysisProgress()
    data class DetectingGenre(val message: String = "Calculating spectral features & genre...") : AnalysisProgress()
    object Completed : AnalysisProgress()
    data class Error(val errorMessage: String) : AnalysisProgress()
}

/**
 * Audio Spectral & Genre details
 */
data class GenreInfo(
    val primaryGenre: String,
    val subGenre: String,
    val confidence: Float,
    val spectralBrightness: Float, // 0.0 (Warm/Dark) to 1.0 (Bright/Crisp)
    val bassDensity: Float,        // 0.0 to 1.0
    val dynamicRangeDb: Float
)

/**
 * Complete result of local audio analysis for a track
 */
data class TrackAnalysisResult(
    val id: String,
    val fileName: String,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val sampleRate: Int,
    val channels: Int,
    val bpm: Float,
    val bpmConfidence: Float,
    val musicalKey: MusicalKey,
    val keyConfidence: Float,
    val genreInfo: GenreInfo,
    val energyLevel: Float, // 0.0 to 1.0
    val danceability: Float, // 0.0 to 1.0
    val waveformPoints: FloatArray, // 100-200 points for visualization
    val uri: Uri?,
    val isDemoSample: Boolean = false
) {
    val formattedDuration: String
        get() {
            val totalSec = durationMs / 1000
            val min = totalSec / 60
            val sec = totalSec % 60
            return "%d:%02d".format(min, sec)
        }

    val roundedBpm: String
        get() = "%.1f".format(bpm)

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as TrackAnalysisResult

        if (id != other.id) return false
        if (fileName != other.fileName) return false
        if (title != other.title) return false
        if (artist != other.artist) return false
        if (durationMs != other.durationMs) return false
        if (bpm != other.bpm) return false
        if (musicalKey != other.musicalKey) return false
        if (genreInfo != other.genreInfo) return false
        if (!waveformPoints.contentEquals(other.waveformPoints)) return false
        if (uri != other.uri) return false

        return true
    }

    override fun hashCode(): Int {
        var result = id.hashCode()
        result = 31 * result + fileName.hashCode()
        result = 31 * result + title.hashCode()
        result = 31 * result + bpm.hashCode()
        result = 31 * result + musicalKey.hashCode()
        result = 31 * result + waveformPoints.contentHashCode()
        return result
    }
}
