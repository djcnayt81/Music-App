package com.example.model

import kotlin.math.abs
import kotlin.math.roundToInt

enum class MashupVerdict(
    val title: String,
    val subtitle: String,
    val colorHex: Long
) {
    PERFECT_MATCH("Perfect Mashup Match", "Zero/minimal adjustment needed. Instant seamless blend!", 0xFF00E676),
    GREAT_HARMONIC_BLEND("Great Harmonic Blend", "Harmonic compatible. Subtle tempo stretch suggested.", 0xFF00E5FF),
    GOOD_WITH_ADJUSTMENTS("Compatible with Adjustments", "Apply suggested pitch shift & tempo sync for great result.", 0xFFFFD600),
    MODERATE_CHALLENGE("Moderate Challenge", "Different energy or tempo gap. Good for creative remix/buildup.", 0xFFFF9100),
    DISSONANT_DIFFICULT("Harmonic Clash / High Gap", "Requires key shift & major time-stretching.", 0xFFFF5252)
}

/**
 * Detailed Mashup Comparison & DJ Recipe recommendations
 */
data class MashupCompatibility(
    val trackA: TrackAnalysisResult,
    val trackB: TrackAnalysisResult,
    val overallScore: Int,         // 0 to 100
    val tempoMatchScore: Int,     // 0 to 100
    val harmonicMatchScore: Int,  // 0 to 100
    val energyMatchScore: Int,    // 0 to 100
    val bpmDifference: Float,
    val bpmRatio: Float,
    val isHalfTimeDoubleTime: Boolean,
    val suggestedMasterBpm: Float,
    val speedChangeTrackAPercent: Float,
    val speedChangeTrackBPercent: Float,
    val recommendedPitchShiftSemitonesB: Int, // Shift Track B to match Track A
    val recommendedPitchShiftSemitonesA: Int, // Shift Track A to match Track B
    val harmonicRelation: KeyCompatibilityHelper.HarmonicRelation,
    val verdict: MashupVerdict,
    val mashupTips: List<String>,
    val transitionStyle: String
) {
    companion object {
        fun compute(trackA: TrackAnalysisResult, trackB: TrackAnalysisResult): MashupCompatibility {
            // 1. Tempo Comparison
            val bpmA = trackA.bpm
            val bpmB = trackB.bpm

            val bpmDiff = abs(bpmA - bpmB)
            val directRatio = if (bpmA > 0) bpmB / bpmA else 1f

            // Half-time / Double-time detection (e.g. 70 BPM trap beat with 140 BPM EDM)
            val halfTimeRatio = if (bpmA > 0) (bpmB * 2f) / bpmA else 1f
            val doubleTimeRatio = if (bpmA > 0) (bpmB / 2f) / bpmA else 1f

            val isHalfTime = abs(halfTimeRatio - 1f) < 0.08f
            val isDoubleTime = abs(doubleTimeRatio - 1f) < 0.08f
            val isHalfDouble = isHalfTime || isDoubleTime

            // Effective normalized BPM for comparison
            val effectiveBpmB = when {
                isHalfTime -> bpmB * 2f
                isDoubleTime -> bpmB / 2f
                else -> bpmB
            }

            val effectiveBpmDiff = abs(bpmA - effectiveBpmB)
            val percentDiff = (effectiveBpmDiff / bpmA) * 100f

            val tempoScore = when {
                percentDiff <= 1.0f -> 100
                percentDiff <= 3.0f -> 95
                percentDiff <= 5.0f -> 88
                percentDiff <= 8.0f -> 75
                percentDiff <= 12.0f -> 60
                percentDiff <= 18.0f -> 45
                else -> maxOf(20, (100 - (percentDiff * 3)).roundToInt())
            }

            // Suggested Master BPM (Weighted average or midpoint)
            val suggestedMasterBpm = ((bpmA + effectiveBpmB) / 2f)
            val speedChangeA = ((suggestedMasterBpm - bpmA) / bpmA) * 100f
            val speedChangeB = ((suggestedMasterBpm - effectiveBpmB) / effectiveBpmB) * 100f

            // 2. Harmonic & Key Comparison
            val keyA = trackA.musicalKey
            val keyB = trackB.musicalKey
            val harmonicRel = KeyCompatibilityHelper.evaluateHarmonicRelation(keyA, keyB)
            val harmonicScore = harmonicRel.score

            val pitchShiftB = KeyCompatibilityHelper.calculatePitchShiftSemitones(keyA, keyB)
            val pitchShiftA = KeyCompatibilityHelper.calculatePitchShiftSemitones(keyB, keyA)

            // 3. Energy & Spectral balance
            val energyDiff = abs(trackA.energyLevel - trackB.energyLevel)
            val energyScore = (100 - (energyDiff * 40)).coerceIn(50f, 100f).roundToInt()

            // 4. Overall Weighted Score (Harmonic 45%, Tempo 40%, Energy 15%)
            val weightedScore = (
                (harmonicScore * 0.45f) +
                (tempoScore * 0.40f) +
                (energyScore * 0.15f)
            ).roundToInt().coerceIn(10, 100)

            // 5. Verdict
            val verdict = when {
                weightedScore >= 92 -> MashupVerdict.PERFECT_MATCH
                weightedScore >= 80 -> MashupVerdict.GREAT_HARMONIC_BLEND
                weightedScore >= 68 -> MashupVerdict.GOOD_WITH_ADJUSTMENTS
                weightedScore >= 50 -> MashupVerdict.MODERATE_CHALLENGE
                else -> MashupVerdict.DISSONANT_DIFFICULT
            }

            // 6. Practical DJ Actionable Tips & Recipe
            val tips = mutableListOf<String>()

            // Rhythmic advice
            if (percentDiff <= 2.0f) {
                tips.add("⚡ BPM Match: Tempos are within 2%. Beats can lock in directly without audible pitch warble.")
            } else if (isHalfDouble) {
                tips.add("🔄 Half-Time / Double-Time Sync: Track A (${"%.1f".format(bpmA)} BPM) and Track B (${"%.1f".format(bpmB)} BPM) share a 2:1 groove relationship. Perfect for vocal over halftime beat!")
            } else {
                tips.add("⏱️ Tempo Sync: Adjust master project to ${"%.1f".format(suggestedMasterBpm)} BPM (Track A: ${if (speedChangeA >= 0) "+" else ""}${"%.1f".format(speedChangeA)}%, Track B: ${if (speedChangeB >= 0) "+" else ""}${"%.1f".format(speedChangeB)}%).")
            }

            // Harmonic advice
            when (harmonicRel) {
                KeyCompatibilityHelper.HarmonicRelation.IDENTICAL -> {
                    tips.add("🎵 Key Harmony: Both tracks are in ${keyA.displayName} (${keyA.camelotCode}). Melodies and basslines will harmonize without clashing.")
                }
                KeyCompatibilityHelper.HarmonicRelation.RELATIVE_MODE -> {
                    tips.add("🎭 Relative Key Switch: ${keyA.displayName} (${keyA.camelotCode}) & ${keyB.displayName} (${keyB.camelotCode}) share the same notes. Superb for emotional transitions.")
                }
                KeyCompatibilityHelper.HarmonicRelation.CAMELOT_PLUS_ONE -> {
                    tips.add("🔥 Energy Lift: Camelot +1 transition (${keyA.camelotCode} ➔ ${keyB.camelotCode}) raises harmonic energy. Ideal for drop mashups!")
                }
                KeyCompatibilityHelper.HarmonicRelation.CAMELOT_MINUS_ONE -> {
                    tips.add("🌊 Deep Energy Blend: Camelot -1 transition (${keyA.camelotCode} ➔ ${keyB.camelotCode}) creates a smooth, calming bridge.")
                }
                else -> {
                    val sign = if (pitchShiftB >= 0) "+$pitchShiftB" else "$pitchShiftB"
                    tips.add("🎛️ Pitch Adjustment: Shift Track B by $sign semitone(s) to match ${keyA.displayName} perfectly.")
                }
            }

            // Genre & Mashup Style advice
            val style = determineTransitionStyle(trackA, trackB, harmonicRel, isHalfDouble)
            tips.add("🎧 Recommended Structure: $style")

            return MashupCompatibility(
                trackA = trackA,
                trackB = trackB,
                overallScore = weightedScore,
                tempoMatchScore = tempoScore,
                harmonicMatchScore = harmonicScore,
                energyMatchScore = energyScore,
                bpmDifference = bpmDiff,
                bpmRatio = directRatio,
                isHalfTimeDoubleTime = isHalfDouble,
                suggestedMasterBpm = suggestedMasterBpm,
                speedChangeTrackAPercent = speedChangeA,
                speedChangeTrackBPercent = speedChangeB,
                recommendedPitchShiftSemitonesB = pitchShiftB,
                recommendedPitchShiftSemitonesA = pitchShiftA,
                harmonicRelation = harmonicRel,
                verdict = verdict,
                mashupTips = tips,
                transitionStyle = style
            )
        }

        private fun determineTransitionStyle(
            trackA: TrackAnalysisResult,
            trackB: TrackAnalysisResult,
            harmonicRel: KeyCompatibilityHelper.HarmonicRelation,
            isHalfDouble: Boolean
        ): String {
            return when {
                isHalfDouble -> "Halftime Vocal/Acapella over Fast Beat"
                harmonicRel == KeyCompatibilityHelper.HarmonicRelation.IDENTICAL -> "Seamless Intro-Outro Overlap or Vocal Overlay"
                harmonicRel == KeyCompatibilityHelper.HarmonicRelation.CAMELOT_PLUS_ONE -> "Energy Drop Switch (Cut Track A at Drop, trigger Track B)"
                trackA.genreInfo.primaryGenre != trackB.genreInfo.primaryGenre -> "Cross-Genre Fusion (Filter Sweep EQ on Transition)"
                else -> "EQ Bass Swap on the 1st beat of the 16-bar chorus"
            }
        }
    }
}
