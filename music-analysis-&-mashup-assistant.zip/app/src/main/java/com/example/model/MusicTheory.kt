package com.example.model

import kotlin.math.abs

/**
 * 12 Chromatic Pitch Classes
 */
enum class PitchClass(val semitone: Int, val sharpName: String, val flatName: String) {
    C(0, "C", "C"),
    C_SHARP(1, "C♯", "D♭"),
    D(2, "D", "D"),
    D_SHARP(3, "D♯", "E♭"),
    E(4, "E", "E"),
    F(5, "F", "F"),
    F_SHARP(6, "F♯", "G♭"),
    G(7, "G", "G"),
    G_SHARP(8, "G♯", "A♭"),
    A(9, "A", "A"),
    A_SHARP(10, "A♯", "B♭"),
    B(11, "B", "B");

    companion object {
        fun fromSemitone(semitone: Int): PitchClass {
            val normalized = ((semitone % 12) + 12) % 12
            return entries.first { it.semitone == normalized }
        }
    }
}

enum class ScaleMode(val label: String, val shortLabel: String) {
    MAJOR("Major", "Maj"),
    MINOR("Minor", "Min")
}

/**
 * Camelot Wheel Notation used by world-class DJs (e.g., 8B for C Major, 8A for A Minor)
 */
data class CamelotCode(val number: Int, val letter: Char) {
    override fun toString(): String = "$number$letter"

    val isMinor: Boolean get() = letter == 'A'
    val isMajor: Boolean get() = letter == 'B'
}

/**
 * Musical Key Representation
 */
data class MusicalKey(
    val pitchClass: PitchClass,
    val mode: ScaleMode,
    val camelotCode: CamelotCode
) {
    val displayName: String
        get() = "${pitchClass.sharpName} ${mode.label}"

    val shortDisplayName: String
        get() = "${pitchClass.sharpName} ${mode.shortLabel}"

    val altDisplayName: String
        get() = if (pitchClass.sharpName != pitchClass.flatName) {
            "${pitchClass.flatName} ${mode.label}"
        } else {
            displayName
        }

    companion object {
        // Standard Camelot mappings
        // Major Keys (B-series)
        val B_MAJOR = MusicalKey(PitchClass.B, ScaleMode.MAJOR, CamelotCode(1, 'B'))
        val F_SHARP_MAJOR = MusicalKey(PitchClass.F_SHARP, ScaleMode.MAJOR, CamelotCode(2, 'B'))
        val D_FLAT_MAJOR = MusicalKey(PitchClass.C_SHARP, ScaleMode.MAJOR, CamelotCode(3, 'B'))
        val A_FLAT_MAJOR = MusicalKey(PitchClass.G_SHARP, ScaleMode.MAJOR, CamelotCode(4, 'B'))
        val E_FLAT_MAJOR = MusicalKey(PitchClass.D_SHARP, ScaleMode.MAJOR, CamelotCode(5, 'B'))
        val B_FLAT_MAJOR = MusicalKey(PitchClass.A_SHARP, ScaleMode.MAJOR, CamelotCode(6, 'B'))
        val F_MAJOR = MusicalKey(PitchClass.F, ScaleMode.MAJOR, CamelotCode(7, 'B'))
        val C_MAJOR = MusicalKey(PitchClass.C, ScaleMode.MAJOR, CamelotCode(8, 'B'))
        val G_MAJOR = MusicalKey(PitchClass.G, ScaleMode.MAJOR, CamelotCode(9, 'B'))
        val D_MAJOR = MusicalKey(PitchClass.D, ScaleMode.MAJOR, CamelotCode(10, 'B'))
        val A_MAJOR = MusicalKey(PitchClass.A, ScaleMode.MAJOR, CamelotCode(11, 'B'))
        val E_MAJOR = MusicalKey(PitchClass.E, ScaleMode.MAJOR, CamelotCode(12, 'B'))

        // Minor Keys (A-series)
        val A_FLAT_MINOR = MusicalKey(PitchClass.G_SHARP, ScaleMode.MINOR, CamelotCode(1, 'A'))
        val E_FLAT_MINOR = MusicalKey(PitchClass.D_SHARP, ScaleMode.MINOR, CamelotCode(2, 'A'))
        val B_FLAT_MINOR = MusicalKey(PitchClass.A_SHARP, ScaleMode.MINOR, CamelotCode(3, 'A'))
        val F_MINOR = MusicalKey(PitchClass.F, ScaleMode.MINOR, CamelotCode(4, 'A'))
        val C_MINOR = MusicalKey(PitchClass.C, ScaleMode.MINOR, CamelotCode(5, 'A'))
        val G_MINOR = MusicalKey(PitchClass.G, ScaleMode.MINOR, CamelotCode(6, 'A'))
        val D_MINOR = MusicalKey(PitchClass.D, ScaleMode.MINOR, CamelotCode(7, 'A'))
        val A_MINOR = MusicalKey(PitchClass.A, ScaleMode.MINOR, CamelotCode(8, 'A'))
        val E_MINOR = MusicalKey(PitchClass.E, ScaleMode.MINOR, CamelotCode(9, 'A'))
        val B_MINOR = MusicalKey(PitchClass.B, ScaleMode.MINOR, CamelotCode(10, 'A'))
        val F_SHARP_MINOR = MusicalKey(PitchClass.F_SHARP, ScaleMode.MINOR, CamelotCode(11, 'A'))
        val C_SHARP_MINOR = MusicalKey(PitchClass.C_SHARP, ScaleMode.MINOR, CamelotCode(12, 'A'))

        val ALL_KEYS: List<MusicalKey> = listOf(
            C_MAJOR, C_SHARP_MINOR, D_FLAT_MAJOR, D_MINOR, D_MAJOR,
            E_FLAT_MINOR, E_FLAT_MAJOR, E_MINOR, E_MAJOR, F_MINOR,
            F_MAJOR, F_SHARP_MINOR, F_SHARP_MAJOR, G_MINOR, G_MAJOR,
            A_FLAT_MINOR, A_FLAT_MAJOR, A_MINOR, A_MAJOR, B_FLAT_MINOR,
            B_FLAT_MAJOR, B_MINOR, B_MAJOR, C_MINOR
        )

        fun find(pitchClass: PitchClass, mode: ScaleMode): MusicalKey {
            return ALL_KEYS.firstOrNull { it.pitchClass == pitchClass && it.mode == mode }
                ?: C_MAJOR
        }

        fun findByCamelot(number: Int, letter: Char): MusicalKey {
            return ALL_KEYS.firstOrNull { it.camelotCode.number == number && it.camelotCode.letter == letter }
                ?: C_MAJOR
        }
    }
}

/**
 * Harmonic Mixing and Pitch Shift Helper
 */
object KeyCompatibilityHelper {

    enum class HarmonicRelation(val score: Int, val description: String, val djTip: String) {
        IDENTICAL(100, "Same Key", "Flawless harmonic match. Blend anytime."),
        RELATIVE_MODE(95, "Relative Major/Minor", "Perfect emotional mood shift (Euphoric <-> Deep)."),
        CAMELOT_PLUS_ONE(90, "Energy Boost (+1)", "Lifts dancefloor energy and tension seamlessly."),
        CAMELOT_MINUS_ONE(85, "Warm Down (-1)", "Creates a deeper, soothing harmonic transition."),
        DOMINANT_FOURTH_FIFTH(75, "Harmonic 4th / 5th", "Modal modulation. Good for drop switches."),
        SEMITONE_SHIFT_SUGGESTED(60, "Key Shift Needed", "Shift pitch by 1 or 2 semitones for instant sync."),
        DISSONANT(30, "Harmonic Clash", "High dissonance. Pitch shift required for mashup.")
    }

    /**
     * Calculates the shortest Camelot wheel distance between two keys (0 to 6)
     */
    fun getCamelotDistance(keyA: MusicalKey, keyB: MusicalKey): Int {
        val numA = keyA.camelotCode.number
        val numB = keyB.camelotCode.number
        val diff = abs(numA - numB)
        return minOf(diff, 12 - diff)
    }

    /**
     * Evaluates harmonic relation between two keys
     */
    fun evaluateHarmonicRelation(keyA: MusicalKey, keyB: MusicalKey): HarmonicRelation {
        val dist = getCamelotDistance(keyA, keyB)
        val sameMode = keyA.camelotCode.letter == keyB.camelotCode.letter

        return when {
            keyA == keyB -> HarmonicRelation.IDENTICAL
            dist == 0 && !sameMode -> HarmonicRelation.RELATIVE_MODE
            dist == 1 && sameMode -> {
                val numA = keyA.camelotCode.number
                val numB = keyB.camelotCode.number
                val isForward = (numB == numA + 1) || (numA == 12 && numB == 1)
                if (isForward) HarmonicRelation.CAMELOT_PLUS_ONE else HarmonicRelation.CAMELOT_MINUS_ONE
            }
            dist == 2 && sameMode -> HarmonicRelation.DOMINANT_FOURTH_FIFTH
            dist <= 3 -> HarmonicRelation.SEMITONE_SHIFT_SUGGESTED
            else -> HarmonicRelation.DISSONANT
        }
    }

    /**
     * Calculates pitch shift in semitones to make Track B match Track A's key (or relative key)
     * Range: -6 to +6 semitones
     */
    fun calculatePitchShiftSemitones(targetKey: MusicalKey, sourceKey: MusicalKey): Int {
        val semitoneTarget = targetKey.pitchClass.semitone
        val semitoneSource = sourceKey.pitchClass.semitone

        var diff = semitoneTarget - semitoneSource
        if (diff > 6) diff -= 12
        if (diff < -6) diff += 12
        return diff
    }
}
