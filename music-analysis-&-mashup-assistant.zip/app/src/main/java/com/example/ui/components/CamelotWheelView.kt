package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MusicalKey
import com.example.ui.theme.DeckACyan
import com.example.ui.theme.DeckBPurple
import com.example.ui.theme.MashupGreen
import com.example.ui.theme.StudioBackground
import com.example.ui.theme.StudioCardBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceContainerHigh
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CamelotWheelView(
    keyA: MusicalKey?,
    keyB: MusicalKey?,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(listOf(StudioCardBorder, StudioCardBorder))
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CAMELOT HARMONIC WHEEL",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextMuted,
                        letterSpacing = 1.3.sp,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(MashupGreen)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Harmonic Map",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Wheel Canvas
            Box(
                modifier = Modifier.size(240.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(240.dp)) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val outerRadius = size.width * 0.46f
                    val midRadius = size.width * 0.32f
                    val innerRadius = size.width * 0.18f

                    // Draw Background Rings
                    drawCircle(
                        color = StudioSurfaceVariant,
                        radius = outerRadius,
                        center = center
                    )
                    drawCircle(
                        color = Color.White,
                        radius = midRadius,
                        center = center
                    )
                    drawCircle(
                        color = StudioSurfaceContainerHigh,
                        radius = innerRadius,
                        center = center
                    )

                    // Draw 12 Segment Dividers
                    for (i in 0 until 12) {
                        val angle = (i * 30.0 - 90.0) * PI / 180.0
                        val start = Offset(
                            (center.x + innerRadius * cos(angle)).toFloat(),
                            (center.y + innerRadius * sin(angle)).toFloat()
                        )
                        val end = Offset(
                            (center.x + outerRadius * cos(angle)).toFloat(),
                            (center.y + outerRadius * sin(angle)).toFloat()
                        )
                        drawLine(
                            color = StudioCardBorder,
                            start = start,
                            end = end,
                            strokeWidth = 1.5f
                        )
                    }

                    // Draw Segment Labels (1B-12B Outer, 1A-12A Inner)
                    val paint = android.graphics.Paint().apply {
                        textAlign = android.graphics.Paint.Align.CENTER
                        textSize = 28f
                        isAntiAlias = true
                        color = android.graphics.Color.argb(200, 30, 41, 59)
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                    }

                    val smallPaint = android.graphics.Paint().apply {
                        textAlign = android.graphics.Paint.Align.CENTER
                        textSize = 22f
                        isAntiAlias = true
                        color = android.graphics.Color.argb(160, 71, 85, 105)
                        typeface = android.graphics.Typeface.DEFAULT_BOLD
                    }

                    for (num in 1..12) {
                        val angleDeg = (num * 30.0 - 90.0)
                        val angleRad = angleDeg * PI / 180.0

                        // Outer position (Major)
                        val outerR = (outerRadius + midRadius) / 2f
                        val outerX = (center.x + outerR * cos(angleRad)).toFloat()
                        val outerY = (center.y + outerR * sin(angleRad)).toFloat() + 9f

                        // Inner position (Minor)
                        val innerR = (midRadius + innerRadius) / 2f
                        val innerX = (center.x + innerR * cos(angleRad)).toFloat()
                        val innerY = (center.y + innerR * sin(angleRad)).toFloat() + 7f

                        drawContext.canvas.nativeCanvas.drawText("${num}B", outerX, outerY, paint)
                        drawContext.canvas.nativeCanvas.drawText("${num}A", innerX, innerY, smallPaint)
                    }

                    // Highlight Key A
                    keyA?.let { k ->
                        drawKeyHighlight(
                            key = k,
                            center = center,
                            outerRadius = outerRadius,
                            midRadius = midRadius,
                            innerRadius = innerRadius,
                            color = DeckACyan,
                            label = "A"
                        )
                    }

                    // Highlight Key B
                    keyB?.let { k ->
                        drawKeyHighlight(
                            key = k,
                            center = center,
                            outerRadius = outerRadius,
                            midRadius = midRadius,
                            innerRadius = innerRadius,
                            color = DeckBPurple,
                            label = "B"
                        )
                    }

                    // Draw connecting chord/line if both keys exist
                    if (keyA != null && keyB != null) {
                        val posA = getKeyPosition(keyA, center, outerRadius, midRadius, innerRadius)
                        val posB = getKeyPosition(keyB, center, outerRadius, midRadius, innerRadius)

                        drawLine(
                            brush = Brush.linearGradient(listOf(DeckACyan, DeckBPurple)),
                            start = posA,
                            end = posB,
                            strokeWidth = 5f,
                            cap = StrokeCap.Round,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                        )
                    }
                }

                // Center Hub Text
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "DJ",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = TextPrimary,
                            fontSize = 18.sp
                        )
                    )
                    Text(
                        text = "CAMELOT",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextMuted,
                            fontSize = 9.sp,
                            letterSpacing = 1.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Key Legend Indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // Deck A Legend
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(DeckACyan)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (keyA != null) "Track A: ${keyA.displayName} (${keyA.camelotCode})" else "Track A: None",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (keyA != null) DeckACyan else TextMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    )
                }

                // Deck B Legend
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(DeckBPurple)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (keyB != null) "Track B: ${keyB.displayName} (${keyB.camelotCode})" else "Track B: None",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = if (keyB != null) DeckBPurple else TextMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    )
                }
            }
        }
    }
}

private fun getKeyPosition(
    key: MusicalKey,
    center: Offset,
    outerRadius: Float,
    midRadius: Float,
    innerRadius: Float
): Offset {
    val angleDeg = (key.camelotCode.number * 30.0 - 90.0)
    val angleRad = angleDeg * PI / 180.0
    val radius = if (key.camelotCode.isMajor) {
        (outerRadius + midRadius) / 2f
    } else {
        (midRadius + innerRadius) / 2f
    }
    return Offset(
        (center.x + radius * cos(angleRad)).toFloat(),
        (center.y + radius * sin(angleRad)).toFloat()
    )
}

private fun DrawScope.drawKeyHighlight(
    key: MusicalKey,
    center: Offset,
    outerRadius: Float,
    midRadius: Float,
    innerRadius: Float,
    color: Color,
    label: String
) {
    val pos = getKeyPosition(key, center, outerRadius, midRadius, innerRadius)

    // Outer Ring
    drawCircle(
        color = color.copy(alpha = 0.25f),
        radius = 18.dp.toPx(),
        center = pos
    )

    // Inner Pin
    drawCircle(
        color = color,
        radius = 12.dp.toPx(),
        center = pos
    )

    // Label Text
    val paint = android.graphics.Paint().apply {
        textAlign = android.graphics.Paint.Align.CENTER
        textSize = 24f
        isAntiAlias = true
        setColor(android.graphics.Color.WHITE)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    drawContext.canvas.nativeCanvas.drawText(label, pos.x, pos.y + 8f, paint)
}

