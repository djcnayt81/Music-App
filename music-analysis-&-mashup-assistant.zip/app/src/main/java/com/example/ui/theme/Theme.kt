package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val StudioColorScheme = lightColorScheme(
    primary = DeckACyan,
    onPrimary = StudioSurface,
    primaryContainer = DeckACyanContainer,
    onPrimaryContainer = DeckACyanOnContainer,
    secondary = DeckBPurple,
    onSecondary = StudioSurface,
    secondaryContainer = DeckBPurpleContainer,
    onSecondaryContainer = DeckBPurpleOnContainer,
    tertiary = MashupGreen,
    onTertiary = StudioSurface,
    tertiaryContainer = MashupGreenContainer,
    background = StudioBackground,
    onBackground = TextPrimary,
    surface = StudioSurface,
    onSurface = TextPrimary,
    surfaceVariant = StudioSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = StudioCardBorder
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StudioColorScheme,
        typography = Typography,
        content = content
    )
}


