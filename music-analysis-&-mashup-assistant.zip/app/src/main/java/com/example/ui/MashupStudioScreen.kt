package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Compare
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CamelotWheelView
import com.example.ui.components.CompatibilityGauge
import com.example.ui.components.DualPlayerDeckView
import com.example.ui.components.MashupRecipeCard
import com.example.ui.components.TrackCard
import com.example.ui.theme.DeckACyan
import com.example.ui.theme.DeckBPurple
import com.example.ui.theme.MashupGreen
import com.example.ui.theme.StudioBackground
import com.example.ui.theme.StudioCardBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MashupStudioScreen(
    viewModel: MashupViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val playerStateA by viewModel.playerStateA.collectAsStateWithLifecycle()
    val playerStateB by viewModel.playerStateB.collectAsStateWithLifecycle()

    // File pickers for Track A and Track B
    val pickerLauncherA = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.analyzeTrack(0, it) }
    }

    val pickerLauncherB = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.analyzeTrack(1, it) }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(StudioBackground),
        containerColor = StudioBackground,
        topBar = {
            StudioTopAppBar(
                onLoadDemoMashup = {
                    viewModel.loadDemoSample(0)
                    viewModel.loadDemoSample(1)
                }
            )
        },
        bottomBar = {
            StudioBottomNav(
                selectedTab = uiState.activeTab,
                onTabSelected = { viewModel.setActiveTab(it) },
                hasMashupReady = uiState.compatibility != null
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .widthIn(max = 700.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            when (uiState.activeTab) {
                0 -> TracksAndAnalysisTab(
                    uiState = uiState,
                    playerStateA = playerStateA,
                    playerStateB = playerStateB,
                    onSelectFileA = { pickerLauncherA.launch("audio/*") },
                    onSelectFileB = { pickerLauncherB.launch("audio/*") },
                    onSampleA = { viewModel.loadDemoSample(0) },
                    onSampleB = { viewModel.loadDemoSample(1) },
                    onPlayPauseA = { viewModel.dualPlayer.togglePlayDeckA() },
                    onPlayPauseB = { viewModel.dualPlayer.togglePlayDeckB() },
                    onSeekA = { progress ->
                        val pos = (progress * (playerStateA.durationMs)).toInt()
                        viewModel.dualPlayer.seekDeckA(pos)
                    },
                    onSeekB = { progress ->
                        val pos = (progress * (playerStateB.durationMs)).toInt()
                        viewModel.dualPlayer.seekDeckB(pos)
                    },
                    onViewMashupClicked = { viewModel.setActiveTab(1) }
                )

                1 -> MashupMatchTab(
                    uiState = uiState,
                    onSwitchToDecks = { viewModel.setActiveTab(0) },
                    onOpenDualDeckPlayer = { viewModel.setActiveTab(2) }
                )

                2 -> DualDeckTab(
                    uiState = uiState,
                    playerStateA = playerStateA,
                    playerStateB = playerStateB,
                    viewModel = viewModel,
                    onSwitchToDecks = { viewModel.setActiveTab(0) }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun StudioTopAppBar(
    onLoadDemoMashup: () -> Unit
) {
    CenterAlignedTopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(DeckACyan, DeckBPurple))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = null,
                        tint = StudioBackground,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "MASHUP STUDIO",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = TextPrimary
                        )
                    )
                    Text(
                        text = "100% Local On-Device DSP",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MashupGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        },
        actions = {
            FilledTonalButton(
                onClick = onLoadDemoMashup,
                modifier = Modifier
                    .padding(end = 8.dp)
                    .testTag("load_demo_mashup_btn"),
                colors = androidx.compose.material3.ButtonDefaults.filledTonalButtonColors(
                    containerColor = StudioSurfaceVariant,
                    contentColor = TextPrimary
                ),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = DeckACyan,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Demo Mashup",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                )
            }
        },
        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
            containerColor = StudioBackground
        )
    )
}

@Composable
private fun StudioBottomNav(
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    hasMashupReady: Boolean
) {
    NavigationBar(
        modifier = Modifier
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("bottom_nav_bar"),
        containerColor = StudioSurface,
        tonalElevation = 0.dp
    ) {
        NavigationBarItem(
            selected = selectedTab == 0,
            onClick = { onTabSelected(0) },
            icon = {
                Icon(
                    imageVector = Icons.Default.LibraryMusic,
                    contentDescription = "Track Analysis"
                )
            },
            label = {
                Text(
                    text = "Tracks",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = StudioBackground,
                selectedTextColor = DeckACyan,
                indicatorColor = DeckACyan,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_tab_tracks")
        )

        NavigationBarItem(
            selected = selectedTab == 1,
            onClick = { onTabSelected(1) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Compare,
                    contentDescription = "Mashup Compatibility"
                )
            },
            label = {
                Text(
                    text = if (hasMashupReady) "Mashup • Ready" else "Mashup",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (hasMashupReady && selectedTab != 1) MashupGreen else TextMuted
                    )
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = StudioBackground,
                selectedTextColor = DeckBPurple,
                indicatorColor = DeckBPurple,
                unselectedIconColor = if (hasMashupReady) MashupGreen else TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_tab_mashup")
        )

        NavigationBarItem(
            selected = selectedTab == 2,
            onClick = { onTabSelected(2) },
            icon = {
                Icon(
                    imageVector = Icons.Default.PlayCircle,
                    contentDescription = "Dual Deck Mixer"
                )
            },
            label = {
                Text(
                    text = "Live Deck",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = StudioBackground,
                selectedTextColor = MashupGreen,
                indicatorColor = MashupGreen,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_tab_player")
        )
    }
}

@Composable
private fun TracksAndAnalysisTab(
    uiState: MashupStudioUiState,
    playerStateA: com.example.audio.engine.DeckPlayerState,
    playerStateB: com.example.audio.engine.DeckPlayerState,
    onSelectFileA: () -> Unit,
    onSelectFileB: () -> Unit,
    onSampleA: () -> Unit,
    onSampleB: () -> Unit,
    onPlayPauseA: () -> Unit,
    onPlayPauseB: () -> Unit,
    onSeekA: (Float) -> Unit,
    onSeekB: (Float) -> Unit,
    onViewMashupClicked: () -> Unit
) {
    val progressA = if (playerStateA.durationMs > 0) playerStateA.currentPositionMs.toFloat() / playerStateA.durationMs else 0f
    val progressB = if (playerStateB.durationMs > 0) playerStateB.currentPositionMs.toFloat() / playerStateB.durationMs else 0f

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Track A Card
        item {
            TrackCard(
                trackLabel = "Track A (Primary Deck)",
                deckIndex = 0,
                trackResult = uiState.trackA,
                progress = uiState.progressA,
                isPlaying = playerStateA.isPlaying,
                playbackProgress = progressA,
                onSelectFileClicked = onSelectFileA,
                onSampleClicked = onSampleA,
                onPlayPauseClicked = onPlayPauseA,
                onSeek = onSeekA
            )
        }

        // Track B Card
        item {
            TrackCard(
                trackLabel = "Track B (Secondary Deck)",
                deckIndex = 1,
                trackResult = uiState.trackB,
                progress = uiState.progressB,
                isPlaying = playerStateB.isPlaying,
                playbackProgress = progressB,
                onSelectFileClicked = onSelectFileB,
                onSampleClicked = onSampleB,
                onPlayPauseClicked = onPlayPauseB,
                onSeek = onSeekB
            )
        }

        // Quick Action to View Mashup if both ready
        if (uiState.compatibility != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = StudioSurface),
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = Brush.linearGradient(listOf(StudioCardBorder, StudioCardBorder))
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Match Score: ${uiState.compatibility.overallScore}%",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        color = DeckACyan
                                    )
                                )
                            }
                            Text(
                                text = "${uiState.compatibility.verdict.title} • Master ${"%.1f".format(uiState.compatibility.suggestedMasterBpm)} BPM",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                            )
                        }

                        Button(
                            onClick = onViewMashupClicked,
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                containerColor = DeckACyan,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "View Blueprint",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }

        // Camelot Harmonic Wheel
        item {
            CamelotWheelView(
                keyA = uiState.trackA?.musicalKey,
                keyB = uiState.trackB?.musicalKey
            )
        }
    }
}

@Composable
private fun MashupMatchTab(
    uiState: MashupStudioUiState,
    onSwitchToDecks: () -> Unit,
    onOpenDualDeckPlayer: () -> Unit
) {
    val compatibility = uiState.compatibility

    if (compatibility == null) {
        // Need both tracks selected
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Compare,
                contentDescription = null,
                tint = DeckBPurple.copy(alpha = 0.7f),
                modifier = Modifier.size(56.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Select 2 Songs to Compare",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Select Track A and Track B from your music library or load demo tracks to compute BPM sync, key compatibility, and pitch adjustments.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextSecondary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            FilledTonalButton(
                onClick = onSwitchToDecks,
                colors = androidx.compose.material3.ButtonDefaults.filledTonalButtonColors(
                    containerColor = DeckACyan,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    text = "Go to Track Selection",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Overall Compatibility Gauge
            item {
                CompatibilityGauge(compatibility = compatibility)
            }

            // Camelot Harmonic Wheel with Active Connection
            item {
                CamelotWheelView(
                    keyA = compatibility.trackA.musicalKey,
                    keyB = compatibility.trackB.musicalKey
                )
            }

            // DJ Mashup Blueprint & Recipe
            item {
                MashupRecipeCard(compatibility = compatibility)
            }

            // Button to open Dual Deck Player
            item {
                Button(
                    onClick = onOpenDualDeckPlayer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = DeckACyan,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayCircle,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Audition Live on Dual Player Deck",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

@Composable
private fun DualDeckTab(
    uiState: MashupStudioUiState,
    playerStateA: com.example.audio.engine.DeckPlayerState,
    playerStateB: com.example.audio.engine.DeckPlayerState,
    viewModel: MashupViewModel,
    onSwitchToDecks: () -> Unit
) {
    val trackA = uiState.trackA
    val trackB = uiState.trackB

    if (trackA == null || trackB == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.GraphicEq,
                contentDescription = null,
                tint = DeckACyan.copy(alpha = 0.7f),
                modifier = Modifier.size(56.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Load Both Tracks to Mix",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Both Track A and Track B need to be loaded to use the interactive Dual Deck Mixer.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextSecondary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            )

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = onSwitchToDecks,
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                    containerColor = DeckACyan,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    text = "Select Tracks",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                DualPlayerDeckView(
                    trackA = trackA,
                    trackB = trackB,
                    stateA = playerStateA,
                    stateB = playerStateB,
                    compatibility = uiState.compatibility,
                    onTogglePlayA = { viewModel.dualPlayer.togglePlayDeckA() },
                    onTogglePlayB = { viewModel.dualPlayer.togglePlayDeckB() },
                    onPlayBoth = { viewModel.dualPlayer.playBothSimultaneously() },
                    onSpeedChangeA = { viewModel.dualPlayer.setSpeedDeckA(it) },
                    onSpeedChangeB = { viewModel.dualPlayer.setSpeedDeckB(it) },
                    onPitchChangeA = { viewModel.dualPlayer.setPitchSemitonesDeckA(it) },
                    onPitchChangeB = { viewModel.dualPlayer.setPitchSemitonesDeckB(it) },
                    onVolumeChangeA = { viewModel.dualPlayer.setVolumeDeckA(it) },
                    onVolumeChangeB = { viewModel.dualPlayer.setVolumeDeckB(it) },
                    onSeekA = { progress ->
                        val pos = (progress * (playerStateA.durationMs)).toInt()
                        viewModel.dualPlayer.seekDeckA(pos)
                    },
                    onSeekB = { progress ->
                        val pos = (progress * (playerStateB.durationMs)).toInt()
                        viewModel.dualPlayer.seekDeckB(pos)
                    },
                    onApplyAutoMashupSync = { viewModel.applyAutoMashupSync() }
                )
            }
        }
    }
}
