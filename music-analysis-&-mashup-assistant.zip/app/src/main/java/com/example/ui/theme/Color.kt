package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sleek Interface Theme Palette
val StudioBackground = Color(0xFFF7F9FF)
val StudioSurface = Color(0xFFFFFFFF)
val StudioSurfaceVariant = Color(0xFFF1F3F9)
val StudioSurfaceContainerHigh = Color(0xFFE1E2EC)
val StudioCardBorder = Color(0xFFDDE2EA)
val StudioCardBorderDashed = Color(0xFFC4C6D0)

// Deck A Identity (Sleek Cobalt Blue)
val DeckACyan = Color(0xFF0061A4)
val DeckACyanDim = Color(0xFF00487B)
val DeckACyanContainer = Color(0xFFD1E4FF)
val DeckACyanOnContainer = Color(0xFF001D36)
val DeckACyanGlow = Color(0x260061A4)

// Deck B Identity (Sleek Indigo / Purple)
val DeckBPurple = Color(0xFF535A92)
val DeckBPurpleDim = Color(0xFF3B4377)
val DeckBPurpleContainer = Color(0xFFE2E0F9)
val DeckBPurpleOnContainer = Color(0xFF10144B)
val DeckBPurpleGlow = Color(0x26535A92)

// Deep Navy Hero Card (Sleek Pro Card)
val DeepHeroBackground = Color(0xFF001D36)
val DeepHeroSurface = Color(0xFF002B4E)
val DeepHeroBorder = Color(0x33D1E4FF)
val DeepHeroTextPrimary = Color(0xFFFFFFFF)
val DeepHeroTextSecondary = Color(0xFFD1E4FF)

// Accents & Mashup Indicators
val MashupGreen = Color(0xFF006E1C)
val MashupGreenContainer = Color(0xFFC8F8B6)
val MashupAmber = Color(0xFF945300)
val MashupAmberContainer = Color(0xFFFFDDB8)
val MashupRed = Color(0xFFBA1A1A)
val MashupRedContainer = Color(0xFFFFDAD6)
val GoldStar = Color(0xFFD97706)

// Text & Neutral Tones
val TextPrimary = Color(0xFF191C20)
val TextSecondary = Color(0xFF44474E)
val TextMuted = Color(0xFF74777F)

