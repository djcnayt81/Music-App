package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.dsp.BpmDetector
import com.example.audio.dsp.GenreDetector
import com.example.audio.dsp.KeyDetector
import com.example.audio.engine.AudioMetadataHelper
import com.example.audio.engine.DualDeckPlayer
import com.example.audio.engine.LocalAudioDecoder
import com.example.audio.engine.SampleAudioGenerator
import com.example.model.AnalysisProgress
import com.example.model.MashupCompatibility
import com.example.model.TrackAnalysisResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

data class MashupStudioUiState(
    val trackA: TrackAnalysisResult? = null,
    val trackB: TrackAnalysisResult? = null,
    val progressA: AnalysisProgress = AnalysisProgress.Idle,
    val progressB: AnalysisProgress = AnalysisProgress.Idle,
    val compatibility: MashupCompatibility? = null,
    val activeTab: Int = 0 // 0: Tracks & Analysis, 1: Mashup Blueprint, 2: Dual Deck Player
)

class MashupViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(MashupStudioUiState())
    val uiState = _uiState.asStateFlow()

    val dualPlayer = DualDeckPlayer(application.applicationContext, viewModelScope)

    val playerStateA = dualPlayer.stateDeckA
    val playerStateB = dualPlayer.stateDeckB

    fun setActiveTab(tabIndex: Int) {
        _uiState.update { it.copy(activeTab = tabIndex) }
    }

    fun analyzeTrack(deckIndex: Int, uri: Uri, isDemoSample: Boolean = false) {
        viewModelScope.launch(Dispatchers.Default) {
            val context = getApplication<Application>().applicationContext

            if (deckIndex == 0) {
                _uiState.update { it.copy(progressA = AnalysisProgress.ReadingMetadata()) }
            } else {
                _uiState.update { it.copy(progressB = AnalysisProgress.ReadingMetadata()) }
            }

            try {
                // 1. Metadata Extraction
                val metadata = AudioMetadataHelper.extractMetadata(context, uri)

                // 2. Local PCM Audio Decoding on CPU
                if (deckIndex == 0) {
                    _uiState.update { it.copy(progressA = AnalysisProgress.DecodingPcm(0)) }
                } else {
                    _uiState.update { it.copy(progressB = AnalysisProgress.DecodingPcm(0)) }
                }

                val decoded = LocalAudioDecoder.decodeAudioLocally(context, uri) { pct ->
                    if (deckIndex == 0) {
                        _uiState.update { it.copy(progressA = AnalysisProgress.DecodingPcm(pct)) }
                    } else {
                        _uiState.update { it.copy(progressB = AnalysisProgress.DecodingPcm(pct)) }
                    }
                }

                // 3. BPM & Rhythm Analysis
                if (deckIndex == 0) {
                    _uiState.update { it.copy(progressA = AnalysisProgress.DetectingBpm()) }
                } else {
                    _uiState.update { it.copy(progressB = AnalysisProgress.DetectingBpm()) }
                }
                val bpmResult = BpmDetector.detectBpm(decoded.pcmMono, decoded.sampleRate)

                // 4. Musical Key & Chromagram Analysis
                if (deckIndex == 0) {
                    _uiState.update { it.copy(progressA = AnalysisProgress.DetectingKey()) }
                } else {
                    _uiState.update { it.copy(progressB = AnalysisProgress.DetectingKey()) }
                }
                val keyResult = KeyDetector.detectKey(decoded.pcmMono, decoded.sampleRate)

                // 5. Genre & Spectral Dynamics
                if (deckIndex == 0) {
                    _uiState.update { it.copy(progressA = AnalysisProgress.DetectingGenre()) }
                } else {
                    _uiState.update { it.copy(progressB = AnalysisProgress.DetectingGenre()) }
                }
                val genreInfo = GenreDetector.analyzeGenre(decoded.pcmMono, decoded.sampleRate, bpmResult.bpm)

                val effectiveDuration = if (metadata.durationMs > 0) metadata.durationMs else decoded.totalDurationMs

                val result = TrackAnalysisResult(
                    id = UUID.randomUUID().toString(),
                    fileName = metadata.fileName,
                    title = metadata.title,
                    artist = metadata.artist,
                    durationMs = effectiveDuration,
                    sampleRate = decoded.sampleRate,
                    channels = decoded.channelCount,
                    bpm = bpmResult.bpm,
                    bpmConfidence = bpmResult.confidence,
                    musicalKey = keyResult.musicalKey,
                    keyConfidence = keyResult.confidence,
                    genreInfo = genreInfo,
                    energyLevel = genreInfo.bassDensity,
                    danceability = (bpmResult.confidence * 0.5f + genreInfo.spectralBrightness * 0.5f).coerceIn(0.4f, 0.95f),
                    waveformPoints = decoded.waveformPoints,
                    uri = uri,
                    isDemoSample = isDemoSample
                )

                // Load into player
                if (deckIndex == 0) {
                    dualPlayer.loadTrackA(uri)
                    _uiState.update {
                        val newA = result
                        val compat = if (it.trackB != null) MashupCompatibility.compute(newA, it.trackB) else null
                        it.copy(
                            trackA = newA,
                            progressA = AnalysisProgress.Completed,
                            compatibility = compat
                        )
                    }
                } else {
                    dualPlayer.loadTrackB(uri)
                    _uiState.update {
                        val newB = result
                        val compat = if (it.trackA != null) MashupCompatibility.compute(it.trackA, newB) else null
                        it.copy(
                            trackB = newB,
                            progressB = AnalysisProgress.Completed,
                            compatibility = compat
                        )
                    }
                }

            } catch (e: Exception) {
                val err = e.localizedMessage ?: "Analysis failed on device."
                if (deckIndex == 0) {
                    _uiState.update { it.copy(progressA = AnalysisProgress.Error(err)) }
                } else {
                    _uiState.update { it.copy(progressB = AnalysisProgress.Error(err)) }
                }
            }
        }
    }

    fun loadDemoSample(deckIndex: Int) {
        viewModelScope.launch {
            val context = getApplication<Application>().applicationContext
            val preset = if (deckIndex == 0) SampleAudioGenerator.PRESET_DECK_A else SampleAudioGenerator.PRESET_DECK_B
            val uri = SampleAudioGenerator.generateDemoWav(context, preset)
            analyzeTrack(deckIndex, uri, isDemoSample = true)
        }
    }

    fun applyAutoMashupSync() {
        val compat = _uiState.value.compatibility ?: return
        val speedA = 1.0f + (compat.speedChangeTrackAPercent / 100f)
        val speedB = 1.0f + (compat.speedChangeTrackBPercent / 100f)

        dualPlayer.setSpeedDeckA(speedA)
        dualPlayer.setSpeedDeckB(speedB)
        dualPlayer.setPitchSemitonesDeckB(compat.recommendedPitchShiftSemitonesB)
    }

    override fun onCleared() {
        super.onCleared()
        dualPlayer.release()
    }
}
