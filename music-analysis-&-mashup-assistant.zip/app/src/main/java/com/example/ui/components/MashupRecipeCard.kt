package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MashupCompatibility
import com.example.ui.theme.DeckACyan
import com.example.ui.theme.DeckACyanContainer
import com.example.ui.theme.DeckBPurple
import com.example.ui.theme.DeckBPurpleContainer
import com.example.ui.theme.MashupGreen
import com.example.ui.theme.StudioBackground
import com.example.ui.theme.StudioCardBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MashupRecipeCard(
    compatibility: MashupCompatibility,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("mashup_recipe_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(
                listOf(StudioCardBorder, StudioCardBorder)
            )
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(DeckACyanContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ElectricBolt,
                            contentDescription = null,
                            tint = DeckACyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = "DJ MASHUP BLUEPRINT",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "Optimal Pitch & Tempo Adjustment Guide",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Master BPM Recommendation Box
            RecommendationStep(
                icon = Icons.Default.Speed,
                iconColor = DeckACyan,
                containerColor = DeckACyanContainer,
                title = "Suggested Master Tempo",
                mainHighlight = "${"%.1f".format(compatibility.suggestedMasterBpm)} BPM",
                details = buildString {
                    append("Track A (${"%.1f".format(compatibility.trackA.bpm)}): ")
                    append(if (compatibility.speedChangeTrackAPercent >= 0) "+" else "")
                    append("${"%.1f".format(compatibility.speedChangeTrackAPercent)}% • ")
                    append("Track B (${"%.1f".format(compatibility.trackB.bpm)}): ")
                    append(if (compatibility.speedChangeTrackBPercent >= 0) "+" else "")
                    append("${"%.1f".format(compatibility.speedChangeTrackBPercent)}%")
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Pitch Shift Recommendation Box
            val shiftB = compatibility.recommendedPitchShiftSemitonesB
            val shiftTextB = when {
                shiftB == 0 -> "0 Semitones (Harmonically In-Tune)"
                shiftB > 0 -> "+$shiftB Semitone(s) Up (➔ ${compatibility.trackA.musicalKey.displayName})"
                else -> "$shiftB Semitone(s) Down (➔ ${compatibility.trackA.musicalKey.displayName})"
            }

            RecommendationStep(
                icon = Icons.Default.MusicNote,
                iconColor = DeckBPurple,
                containerColor = DeckBPurpleContainer,
                title = "Pitch Adjustment (Track B)",
                mainHighlight = shiftTextB,
                details = "Harmonizes Track B (${compatibility.trackB.musicalKey.camelotCode}) directly to Track A (${compatibility.trackA.musicalKey.camelotCode})"
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Transition Strategy Box
            RecommendationStep(
                icon = Icons.Default.Tune,
                iconColor = MashupGreen,
                containerColor = MashupGreen.copy(alpha = 0.15f),
                title = "Mashup Mixing Strategy",
                mainHighlight = compatibility.transitionStyle,
                details = compatibility.harmonicRelation.djTip
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Actionable DJ Tips List
            Text(
                text = "ACTIONABLE DJ TIPS",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextMuted,
                    letterSpacing = 1.2.sp,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                for (tip in compatibility.mashupTips) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(StudioSurfaceVariant)
                            .padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Text(
                            text = tip,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextPrimary,
                                fontSize = 12.sp,
                                lineHeight = 16.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Copy Recipe Button
            Button(
                onClick = {
                    val recipeText = generateShareableRecipe(compatibility)
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Mashup Recipe", recipeText))
                    Toast.makeText(context, "Mashup Blueprint copied to clipboard!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("copy_recipe_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = DeckACyan,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = Color.White
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Copy Mashup Blueprint & Settings",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
            }
        }
    }
}

@Composable
private fun RecommendationStep(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    containerColor: Color,
    title: String,
    mainHighlight: String,
    details: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(StudioSurfaceVariant)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(containerColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            )
            Text(
                text = mainHighlight,
                style = MaterialTheme.typography.titleSmall.copy(
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            )
            Text(
                text = details,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            )
        }
    }
}

private fun generateShareableRecipe(c: MashupCompatibility): String {
    return """
        🎵 DJ MASHUP BLUEPRINT 🎵
        ================================
        Track A: ${c.trackA.title} (${"%.1f".format(c.trackA.bpm)} BPM, ${c.trackA.musicalKey.displayName} - ${c.trackA.musicalKey.camelotCode})
        Track B: ${c.trackB.title} (${"%.1f".format(c.trackB.bpm)} BPM, ${c.trackB.musicalKey.displayName} - ${c.trackB.musicalKey.camelotCode})
        
        ⭐ Compatibility: ${c.overallScore}% (${c.verdict.title})
        🎯 Master BPM: ${"%.1f".format(c.suggestedMasterBpm)} BPM
           - Track A Speed: ${if (c.speedChangeTrackAPercent >= 0) "+" else ""}${"%.1f".format(c.speedChangeTrackAPercent)}%
           - Track B Speed: ${if (c.speedChangeTrackBPercent >= 0) "+" else ""}${"%.1f".format(c.speedChangeTrackBPercent)}%
        
        🎛️ Pitch Shift:
           - Shift Track B by ${if (c.recommendedPitchShiftSemitonesB >= 0) "+" else ""}${c.recommendedPitchShiftSemitonesB} semitone(s) to match ${c.trackA.musicalKey.displayName}
        
        🎧 Transition Strategy: ${c.transitionStyle}
        ================================
        Generated with Music Analysis & Mashup Assistant (100% On-Device DSP)
    """.trimIndent()
}

