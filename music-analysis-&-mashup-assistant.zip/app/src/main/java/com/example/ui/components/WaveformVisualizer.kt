package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun WaveformVisualizer(
    waveformPoints: FloatArray,
    primaryColor: Color,
    secondaryColor: Color = primaryColor.copy(alpha = 0.4f),
    playbackProgress: Float = 0f, // 0.0 to 1.0
    height: Dp = 56.dp,
    modifier: Modifier = Modifier,
    onSeek: ((Float) -> Unit)? = null
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .then(
                if (onSeek != null) {
                    Modifier.pointerInput(Unit) {
                        detectTapGestures { offset ->
                            val progress = (offset.x / size.width).coerceIn(0f, 1f)
                            onSeek(progress)
                        }
                    }
                } else Modifier
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val heightPx = size.height
            val centerY = heightPx / 2f

            if (waveformPoints.isEmpty()) {
                // Placeholder bars
                val dummyCount = 40
                val barWidth = (width / dummyCount) * 0.6f
                val spacing = width / dummyCount
                for (i in 0 until dummyCount) {
                    val x = i * spacing
                    val barH = (heightPx * 0.25f)
                    drawRoundRect(
                        color = primaryColor.copy(alpha = 0.2f),
                        topLeft = Offset(x, centerY - barH / 2f),
                        size = Size(barWidth, barH),
                        cornerRadius = CornerRadius(4f, 4f)
                    )
                }
                return@Canvas
            }

            val count = waveformPoints.size
            val barSpacing = width / count
            val barWidth = (barSpacing * 0.7f).coerceAtLeast(2f)

            val playedWidth = width * playbackProgress.coerceIn(0f, 1f)

            for (i in 0 until count) {
                val x = i * barSpacing
                val amplitude = waveformPoints[i].coerceIn(0.1f, 1.0f)
                val barH = (amplitude * (heightPx * 0.9f)).coerceAtLeast(4f)
                val topY = centerY - (barH / 2f)

                val isPlayed = x <= playedWidth
                val color = if (isPlayed) {
                    primaryColor
                } else {
                    secondaryColor
                }

                drawRoundRect(
                    color = color,
                    topLeft = Offset(x, topY),
                    size = Size(barWidth, barH),
                    cornerRadius = CornerRadius(2f, 2f)
                )
            }

            // Playback Cursor Line
            if (playbackProgress > 0f) {
                val cursorX = width * playbackProgress
                drawLine(
                    color = Color.White,
                    start = Offset(cursorX, 0f),
                    end = Offset(cursorX, heightPx),
                    strokeWidth = 3f
                )
            }
        }
    }
}
