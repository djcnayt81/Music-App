package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MashupCompatibility
import com.example.ui.theme.DeckACyan
import com.example.ui.theme.DeckACyanContainer
import com.example.ui.theme.DeckBPurple
import com.example.ui.theme.DeepHeroBackground
import com.example.ui.theme.DeepHeroBorder
import com.example.ui.theme.DeepHeroSurface
import com.example.ui.theme.DeepHeroTextPrimary
import com.example.ui.theme.DeepHeroTextSecondary
import com.example.ui.theme.MashupAmber
import com.example.ui.theme.MashupGreen
import com.example.ui.theme.MashupRed

@Composable
fun CompatibilityGauge(
    compatibility: MashupCompatibility,
    modifier: Modifier = Modifier
) {
    val animatedProgress = remember { Animatable(0f) }

    LaunchedEffect(compatibility.overallScore) {
        animatedProgress.animateTo(
            targetValue = compatibility.overallScore / 100f,
            animationSpec = tween(durationMillis = 900)
        )
    }

    val scoreColor = when {
        compatibility.overallScore >= 88 -> Color(0xFF4ADE80)
        compatibility.overallScore >= 75 -> Color(0xFF60A5FA)
        compatibility.overallScore >= 60 -> Color(0xFFFBBF24)
        else -> Color(0xFFF87171)
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DeepHeroBackground),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(listOf(DeepHeroBorder, DeepHeroBorder))
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "MASHUP COMPATIBILITY SCORE",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = DeepHeroTextSecondary.copy(alpha = 0.8f),
                    letterSpacing = 1.4.sp,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Circular Gauge Box
            Box(
                modifier = Modifier.size(170.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(160.dp)) {
                    val strokeWidth = 14.dp.toPx()
                    val arcSize = size.width - strokeWidth
                    val startAngle = 135f
                    val sweepAngle = 270f

                    // Background Track
                    drawArc(
                        color = DeepHeroSurface,
                        startAngle = startAngle,
                        sweepAngle = sweepAngle,
                        useCenter = false,
                        topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f),
                        size = Size(arcSize, arcSize),
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )

                    // Active Colored Gauge
                    val activeSweep = sweepAngle * animatedProgress.value
                    if (activeSweep > 0f) {
                        drawArc(
                            brush = Brush.sweepGradient(
                                listOf(Color(0xFF38BDF8), scoreColor, scoreColor)
                            ),
                            startAngle = startAngle,
                            sweepAngle = activeSweep,
                            useCenter = false,
                            topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f),
                            size = Size(arcSize, arcSize),
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "${compatibility.overallScore}",
                            style = MaterialTheme.typography.displayMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = DeepHeroTextPrimary,
                                fontSize = 44.sp
                            )
                        )
                        Text(
                            text = "%",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = DeepHeroTextSecondary,
                                fontSize = 20.sp
                            ),
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }

                    Text(
                        text = "MATCH",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = DeepHeroTextSecondary,
                            letterSpacing = 1.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Verdict Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(30.dp))
                    .background(DeepHeroSurface)
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = compatibility.verdict.title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = scoreColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = compatibility.verdict.subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = DeepHeroTextSecondary,
                    fontSize = 12.sp
                ),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Sub-scores Breakdown (Harmonic, Tempo, Energy)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SubScoreItem(
                    title = "Harmonic",
                    score = compatibility.harmonicMatchScore,
                    subtitle = compatibility.harmonicRelation.description,
                    color = Color(0xFF67E8F9),
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(8.dp))

                SubScoreItem(
                    title = "Tempo / BPM",
                    score = compatibility.tempoMatchScore,
                    subtitle = if (compatibility.isHalfTimeDoubleTime) "2:1 Half-Time" else "${"%.1f".format(compatibility.bpmDifference)} Δ BPM",
                    color = Color(0xFFC084FC),
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(8.dp))

                SubScoreItem(
                    title = "Energy Match",
                    score = compatibility.energyMatchScore,
                    subtitle = "Dynamics Sync",
                    color = Color(0xFF4ADE80),
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun SubScoreItem(
    title: String,
    score: Int,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(DeepHeroSurface)
            .padding(10.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = DeepHeroTextSecondary.copy(alpha = 0.8f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "$score%",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = color,
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = DeepHeroTextSecondary,
                    fontSize = 10.sp
                ),
                maxLines = 1
            )
        }
    }
}

