package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.engine.DeckPlayerState
import com.example.model.MashupCompatibility
import com.example.model.TrackAnalysisResult
import com.example.ui.theme.DeckACyan
import com.example.ui.theme.DeckACyanContainer
import com.example.ui.theme.DeckBPurple
import com.example.ui.theme.DeckBPurpleContainer
import com.example.ui.theme.MashupGreen
import com.example.ui.theme.StudioBackground
import com.example.ui.theme.StudioCardBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun DualPlayerDeckView(
    trackA: TrackAnalysisResult,
    trackB: TrackAnalysisResult,
    stateA: DeckPlayerState,
    stateB: DeckPlayerState,
    compatibility: MashupCompatibility?,
    onTogglePlayA: () -> Unit,
    onTogglePlayB: () -> Unit,
    onPlayBoth: () -> Unit,
    onSpeedChangeA: (Float) -> Unit,
    onSpeedChangeB: (Float) -> Unit,
    onPitchChangeA: (Int) -> Unit,
    onPitchChangeB: (Int) -> Unit,
    onVolumeChangeA: (Float) -> Unit,
    onVolumeChangeB: (Float) -> Unit,
    onSeekA: (Float) -> Unit,
    onSeekB: (Float) -> Unit,
    onApplyAutoMashupSync: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("dual_deck_view"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = StudioSurface),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = Brush.linearGradient(
                listOf(StudioCardBorder, StudioCardBorder)
            )
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Deck Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(DeckACyanContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = DeckACyan,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "LIVE DUAL MIXER DECK",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = TextPrimary
                        )
                    )
                }

                // Auto Sync Button
                if (compatibility != null) {
                    FilledTonalButton(
                        onClick = onApplyAutoMashupSync,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = DeckACyanContainer,
                            contentColor = DeckACyan
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoFixHigh,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Apply Mashup Sync",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Master Dual Play Button
            val bothPlaying = stateA.isPlaying && stateB.isPlaying
            Button(
                onClick = onPlayBoth,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("dual_play_both_btn"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (bothPlaying) Color(0xFF16A34A) else DeckACyan,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(
                    imageVector = if (bothPlaying) Icons.Default.Pause else Icons.Default.Sync,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (bothPlaying) "Pause Dual Mashup Preview" else "Sync & Play Both Decks Together",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Deck A Section (Cobalt Blue)
            DeckControlUnit(
                deckLabel = "DECK A",
                title = trackA.title,
                baseBpm = trackA.bpm,
                musicalKey = trackA.musicalKey.displayName,
                camelot = trackA.musicalKey.camelotCode.toString(),
                themeColor = DeckACyan,
                containerColor = DeckACyanContainer,
                state = stateA,
                waveform = trackA.waveformPoints,
                onTogglePlay = onTogglePlayA,
                onSpeedChange = onSpeedChangeA,
                onPitchChange = onPitchChangeA,
                onVolumeChange = onVolumeChangeA,
                onSeek = onSeekA
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Deck B Section (Indigo)
            DeckControlUnit(
                deckLabel = "DECK B",
                title = trackB.title,
                baseBpm = trackB.bpm,
                musicalKey = trackB.musicalKey.displayName,
                camelot = trackB.musicalKey.camelotCode.toString(),
                themeColor = DeckBPurple,
                containerColor = DeckBPurpleContainer,
                state = stateB,
                waveform = trackB.waveformPoints,
                onTogglePlay = onTogglePlayB,
                onSpeedChange = onSpeedChangeB,
                onPitchChange = onPitchChangeB,
                onVolumeChange = onVolumeChangeB,
                onSeek = onSeekB
            )
        }
    }
}

@Composable
private fun DeckControlUnit(
    deckLabel: String,
    title: String,
    baseBpm: Float,
    musicalKey: String,
    camelot: String,
    themeColor: Color,
    containerColor: Color,
    state: DeckPlayerState,
    waveform: FloatArray,
    onTogglePlay: () -> Unit,
    onSpeedChange: (Float) -> Unit,
    onPitchChange: (Int) -> Unit,
    onVolumeChange: (Float) -> Unit,
    onSeek: (Float) -> Unit
) {
    val currentEffectiveBpm = baseBpm * state.speedMultiplier
    val progress = if (state.durationMs > 0) state.currentPositionMs.toFloat() / state.durationMs else 0f

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(StudioSurfaceVariant)
            .padding(14.dp)
    ) {
        // Deck Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(containerColor)
                        .padding(horizontal = 7.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = deckLabel,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = themeColor,
                            fontWeight = FontWeight.Black,
                            fontSize = 10.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    ),
                    maxLines = 1
                )
            }

            Text(
                text = "${"%.1f".format(currentEffectiveBpm)} BPM • $camelot",
                style = MaterialTheme.typography.bodySmall.copy(
                    color = themeColor,
                    fontWeight = FontWeight.Bold
                )
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Mini Waveform & Play button
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onTogglePlay,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(themeColor)
            ) {
                Icon(
                    imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            WaveformVisualizer(
                waveformPoints = waveform,
                primaryColor = themeColor,
                playbackProgress = progress,
                height = 36.dp,
                modifier = Modifier.weight(1f),
                onSeek = onSeek
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Speed / Tempo Slider Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Speed: ${"%.2f".format(state.speedMultiplier)}x",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                ),
                modifier = Modifier.width(80.dp)
            )

            Slider(
                value = state.speedMultiplier,
                onValueChange = onSpeedChange,
                valueRange = 0.85f..1.15f,
                modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(
                    thumbColor = themeColor,
                    activeTrackColor = themeColor,
                    inactiveTrackColor = Color.White
                )
            )
        }

        // Pitch Shift & Volume Controls Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Pitch Shifter Stepper
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Pitch:",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                )
                Spacer(modifier = Modifier.width(6.dp))

                FilledTonalIconButton(
                    onClick = { onPitchChange((state.pitchSemitones - 1).coerceAtLeast(-6)) },
                    modifier = Modifier.size(28.dp),
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = Color.White,
                        contentColor = TextPrimary
                    )
                ) {
                    Icon(Icons.Default.Remove, contentDescription = "Pitch down", modifier = Modifier.size(14.dp))
                }

                Spacer(modifier = Modifier.width(6.dp))

                Text(
                    text = "${if (state.pitchSemitones >= 0) "+" else ""}${state.pitchSemitones} st",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = if (state.pitchSemitones != 0) themeColor else TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                )

                Spacer(modifier = Modifier.width(6.dp))

                FilledTonalIconButton(
                    onClick = { onPitchChange((state.pitchSemitones + 1).coerceAtMost(6)) },
                    modifier = Modifier.size(28.dp),
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = Color.White,
                        contentColor = TextPrimary
                    )
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Pitch up", modifier = Modifier.size(14.dp))
                }
            }

            // Volume Control
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.width(130.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.VolumeUp,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Slider(
                    value = state.volume,
                    onValueChange = onVolumeChange,
                    valueRange = 0f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = themeColor,
                        activeTrackColor = themeColor,
                        inactiveTrackColor = Color.White
                    )
                )
            }
        }
    }
}

