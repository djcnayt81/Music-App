package com.example

import com.example.model.GenreInfo
import com.example.model.KeyCompatibilityHelper
import com.example.model.MashupCompatibility
import com.example.model.MashupVerdict
import com.example.model.MusicalKey
import com.example.model.PitchClass
import com.example.model.ScaleMode
import com.example.model.TrackAnalysisResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testCamelotDistanceCalculation() {
        // C Major (8B) and G Major (9B) -> Distance 1
        assertEquals(1, KeyCompatibilityHelper.getCamelotDistance(MusicalKey.C_MAJOR, MusicalKey.G_MAJOR))

        // C Major (8B) and A Minor (8A) -> Distance 0 (Relative)
        assertEquals(0, KeyCompatibilityHelper.getCamelotDistance(MusicalKey.C_MAJOR, MusicalKey.A_MINOR))

        // 12B (E Major) and 1B (B Major) -> Distance 1 (Wrap-around circular distance)
        assertEquals(1, KeyCompatibilityHelper.getCamelotDistance(MusicalKey.E_MAJOR, MusicalKey.B_MAJOR))
    }

    @Test
    fun testHarmonicRelations() {
        // Same key
        val relIdentical = KeyCompatibilityHelper.evaluateHarmonicRelation(MusicalKey.C_MAJOR, MusicalKey.C_MAJOR)
        assertEquals(KeyCompatibilityHelper.HarmonicRelation.IDENTICAL, relIdentical)

        // Relative Major / Minor
        val relRelative = KeyCompatibilityHelper.evaluateHarmonicRelation(MusicalKey.C_MAJOR, MusicalKey.A_MINOR)
        assertEquals(KeyCompatibilityHelper.HarmonicRelation.RELATIVE_MODE, relRelative)

        // Camelot +1 Energy Boost (8B to 9B)
        val relPlusOne = KeyCompatibilityHelper.evaluateHarmonicRelation(MusicalKey.C_MAJOR, MusicalKey.G_MAJOR)
        assertEquals(KeyCompatibilityHelper.HarmonicRelation.CAMELOT_PLUS_ONE, relPlusOne)
    }

    @Test
    fun testPitchShiftCalculation() {
        // Shift from D Major (D: semitone 2) to C Major (C: semitone 0) -> -2 semitones
        val shift = KeyCompatibilityHelper.calculatePitchShiftSemitones(MusicalKey.C_MAJOR, MusicalKey.D_MAJOR)
        assertEquals(-2, shift)

        // Shift from A Major (A: semitone 9) to C Major (C: semitone 0 = 12) -> +3 semitones
        val shiftUp = KeyCompatibilityHelper.calculatePitchShiftSemitones(MusicalKey.C_MAJOR, MusicalKey.A_MAJOR)
        assertEquals(3, shiftUp)
    }

    @Test
    fun testMashupCompatibilityComputation() {
        val dummyGenre = GenreInfo("EDM / Dance", "Club", 0.9f, 0.7f, 0.6f, 12f)
        val dummyWaveform = FloatArray(10) { 0.5f }

        val trackA = TrackAnalysisResult(
            id = "1",
            fileName = "trackA.mp3",
            title = "Track A",
            artist = "Artist A",
            durationMs = 180000L,
            sampleRate = 22050,
            channels = 2,
            bpm = 128.0f,
            bpmConfidence = 0.95f,
            musicalKey = MusicalKey.C_MAJOR,
            keyConfidence = 0.9f,
            genreInfo = dummyGenre,
            energyLevel = 0.8f,
            danceability = 0.85f,
            waveformPoints = dummyWaveform,
            uri = null
        )

        val trackB = TrackAnalysisResult(
            id = "2",
            fileName = "trackB.mp3",
            title = "Track B",
            artist = "Artist B",
            durationMs = 190000L,
            sampleRate = 22050,
            channels = 2,
            bpm = 126.0f,
            bpmConfidence = 0.92f,
            musicalKey = MusicalKey.A_MINOR,
            keyConfidence = 0.88f,
            genreInfo = dummyGenre,
            energyLevel = 0.75f,
            danceability = 0.8f,
            waveformPoints = dummyWaveform,
            uri = null
        )

        val compatibility = MashupCompatibility.compute(trackA, trackB)

        // High compatibility due to 128 vs 126 BPM (< 2%) and Relative C Maj / A Min key match
        assertTrue(compatibility.overallScore >= 85)
        assertEquals(127.0f, compatibility.suggestedMasterBpm, 0.5f)
        assertTrue(compatibility.verdict == MashupVerdict.PERFECT_MATCH || compatibility.verdict == MashupVerdict.GREAT_HARMONIC_BLEND)
    }
}

